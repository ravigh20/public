# Primary sources and interpretation

Sources consulted on September 16, 2026. These are technical references, not confirmation of a particular customer tenant, current license entitlement, or control implementation.

Some ServiceNow sources are versioned Zurich documentation and the Data Privacy source is an Australia documentation route. Match the installed release and feature; do not treat this mixture as a claim that either release is universally current. Online documentation can change after this package was generated.

Requirements not accompanied by a vendor source are proposed organizational safeguards, not statements of vendor defaults or product availability.

## OWASP-LLM — OWASP Gen AI Security Project: LLM Top 10

https://genai.owasp.org/llm-top-10/

Threat taxonomy; not a certification or a complete SaaS control standard.

## SF-APEX — Salesforce Lightning Web Components Developer Guide: Secure Apex Classes

https://developer.salesforce.com/docs/platform/lwc/guide/apex-security.html

Apex sharing and object/field access are separate checks. Apply the relevant secure Apex mechanisms to custom AI actions.

## SF-TRUST — Salesforce Agentforce Developer Guide: Trust Layer

https://developer.salesforce.com/docs/ai/agentforce/guide/trust.html

General Trust Layer overview and third-party model retention commitments; confirm coverage for the selected feature and route.

## SN-ACCESS — ServiceNow Zurich: Security for AI agents

https://www.servicenow.com/docs/r/zurich/intelligent-experiences/aia-security-implementation.html

Invocation ACLs, execution identity, role masking and supervised tools; verify behavior for the installed release.

## SN-GUARDIAN — ServiceNow Zurich: AI Guardian

https://www.servicenow.com/docs/r/zurich/intelligent-experiences/now-assist-guardian.html

Logging versus blocking, skill coverage and probabilistic limitations; verify the selected skill and installed version.

## SN-OPT-OUT — ServiceNow Zurich: Opt out of data sharing for Now Assist

https://www.servicenow.com/docs/r/zurich/intelligent-experiences/opt-out-of-data-sharing-for-now-assist.html

Instance-specific opt-out; request submission and effective processing are different. Confirm completion before restricted use.

## SN-OVERFLOW — ServiceNow Zurich: Configure Now Assist data overflow processing

https://www.servicenow.com/docs/r/zurich/intelligent-experiences/configure-na-data-overflow.html

Review the feature-specific overflow setting and processing location with the vendor; do not assume instance residency covers inference.

## SN-PRIVACY — ServiceNow: Configuring Data Privacy for ServiceNow Otto

https://www.servicenow.com/docs/r/platform-security/data-privacy-classic/configure-now-assist-data-privacy.html

Australia documentation: Data Privacy prerequisites and distinct data channels; match to the actual installed product.

## SN-ROLE-MASK — ServiceNow Zurich: Role masking

https://www.servicenow.com/docs/r/zurich/intelligent-experiences/aia-role-masking.html

Use together with the security implementation documentation; validate effective identity through delegation.

## SN-SKILL-ACL — ServiceNow: Configure security controls for a skill

https://www.servicenow.com/docs/r/intelligent-experiences/now-assist-skill-kit/nask-access-control.html

Skill-level invocation ACL configuration; source data authorization remains a separate concern.

## Checker implementation references

PyYAML safe loading: https://pyyaml.org/wiki/PyYAMLDocumentation

pytest parametrized cases: https://docs.pytest.org/en/stable/how-to/parametrize.html

No source is fetched by the local checker. Source availability and content are not tested during offline checks.
