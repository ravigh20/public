# ABC — SaaS AI Enablement Security Controls

**Three YAML definitions. Shared baseline plus vendor overlays. No diagrams, deployment, or tenant API calls.**

This package defines proposed requirements for enabling AI within an existing SaaS platform. It covers traditional solution security and AI-specific risks, while separating customer configuration, vendor responsibility, and independent evidence review.

## Files to start with

| File | Purpose | Controls |
|---|---|---:|
| `saas-ai-enablement-baseline.yaml` | Shared SaaS AI security requirements | 60 |
| `salesforce-ai-enablement.yaml` | Salesforce-specific implementation requirements, inheriting the baseline | 22 additional |
| `service-now-ai-enablement.yaml` | ServiceNow-specific implementation requirements, inheriting the baseline | 24 additional |

There are **106 unique control definitions across 16 domains**. A Salesforce review includes up to **82 controls**; a ServiceNow review includes up to **84 controls**. Conditional requirements apply only to the declared capabilities. These numbers measure the catalog, not protection, compliance, or completeness of an assessment.

The baseline is written once. An overlay references it through `depends_on`, and its controls map back through `supports_baseline`. It cannot replace or weaken the baseline.

## Important boundaries

- These are **draft organizational requirements**, not verified settings or vendor assurances.
- `required_settings` contains **logical review assertions**. The keys are not Salesforce Metadata API fields or ServiceNow system property names. Do not upload these YAMLs into a tenant as configuration.
- Verify the exact feature, SKU, release, instance/org, model route, audience, processing region, and connector/tool selection. Availability varies; a required safeguard that is unsupported remains a gap.
- The conservative ABC data policy prohibits **PII, SI, and HSI** in AI inputs/outputs. This is a proposed organizational restriction, not a vendor prohibition. Changing the allowed classifications requires a reviewed policy decision.
- Customer content must not be reused for shared-model training or product improvement under the proposed baseline. No fine-tuning is authorized.
- Retrieval, agents, tools, write actions, external audiences, custom models, and persistent memory need feature-scoped review. A control describing an extension is not permission to enable it.
- SaaS-only review does **not** impose GAI AKS, Azure subscription, or customer-managed private endpoint requirements on vendor infrastructure.
- Passing local tests cannot establish deployment security, vendor behavior, evidence authenticity, or Security Authority approval.

## Security coverage

| Area | Coverage examples |
|---|---|
| Governance and scope | Feature inventory, responsibility, delta review, pilots, scoped exceptions, material change |
| Identity and access | SSO/MFA, entitlements, least privilege, administrators, joiner/mover/leaver, execution identity |
| Data protection | Classification, field minimization, row/record/field/source permissions, DLP, masking, tenant/session isolation |
| Cryptography and secrets | Complete-path encryption, key-coverage evidence, credential references, OAuth scopes, rotation/revocation |
| Privacy and lifecycle | No secondary reuse, provider versus platform retention, feedback, histories, deletion, legal hold, residency/overflow |
| Networks and integrations | Approved domains/routes, exfiltration/SSRF controls, APIs, webhooks, connectors, custom code, packages, MCP |
| AI-specific risks | Prompt injection, untrusted outputs, grounding, prompt secrecy limits, feature protection coverage, safe failure |
| Agents and actions | Tool allowlists, effective identity, delegated authority, per-action authorization, trusted approval, budgets, recovery, memory |
| Retrieval | Source integrity, query-time permissions, protected citations, revocation/deletion propagation |
| Monitoring and assurance | Audit events, SIEM visibility, protected logs, feature-scoped positive/negative implementation tests |
| Operations | Supplier review, incident handling, disablement, recovery/manual fallback, consumption, change control, offboarding |
| Specialized scope | External/guest channels, multimodal inputs, privacy/legal/model-risk reviews |

Every control has an ID, requirement, implementation guidance, responsibility, applicability, evidence requirement, and a concrete negative scenario. **94 controls have declaration assertions and 12 are evidence-only.** Even the 94 need implementation evidence. The 106 negative scenarios are proposed tenant validation activities; this package does not execute those activities against either vendor.

See `CONTROL-INDEX.md` for the full control inventory without reading all YAML lines.

## Vendor-specific depth

### Salesforce

The overlay addresses feature/org entitlements, permission sets, execution identities, object/field/record permissions, Flow context, secure Apex, Prompt Builder, Trust Layer feature coverage, model-provider retention versus platform-held data, Data Cloud/Data 360 boundaries, search/Knowledge, connected apps and credentials, guest channels, write approvals, available audit events, custom model routes, encryption coverage, packages/MCP, and memory/feedback.

Specific review distinctions include:
- `with sharing` does not replace object/field permission enforcement in custom Apex.
- Do not infer every AI feature's masking/guardrail coverage from the Trust Layer name.
- Third-party-model zero-retention commitments are not a claim that the platform stores no AI histories, logs, or feedback.

### ServiceNow

The overlay addresses instance/plugin/skill inventory, administrative roles, table/record/field/attachment access, skill and agent invocation ACLs, effective run-as identity, dynamic-user role masking versus fixed AI-user privileges, delegated execution, supervised actions, Generative AI Controller/provider routes, effective data-sharing opt-out, overflow residency, Data Privacy channel coverage, Guardian behavior, Search/Knowledge, domain separation, IntegrationHub, optional MID Servers, custom scripts, portals, memory, logs, disablement, and clone/upgrade revalidation.

Specific review distinctions include:
- Permission to invoke an agent is not the same as the principal and privileges used when it executes.
- The cited Zurich security documentation distinguishes dynamic-user role masking from fixed AI-user permissions; verify the installed release.
- An opt-out request is not proof that opt-out is already effective on every instance.
- Guardian logging and Guardian blocking are different outcomes. Check coverage and actual enforcement for the selected skills.

Sources and version limitations are recorded inside the YAML and in `SOURCES.md`. Most control requirements are proposed organizational policy, not quotations or claims about product defaults.

## Run the checks

Use Python 3.11 or later. From this directory:

```bash
python -m pip install -r requirements.txt
python saas_enablement.py check
python -m pytest -q
```

Windows PowerShell, without changing activation policy:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe saas_enablement.py check
.\.venv\Scripts\python.exe -m pytest -q
```

macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python saas_enablement.py check
.venv/bin/python -m pytest -q
```

The executed run used **Python 3.13.5 on Linux, PyYAML 6.0.3, and pytest 9.0.2**. Windows and other Python versions were not executed here. Top-level dependencies are pinned; this is not a transitive lockfile or vulnerability certification. Installation may require your approved package source; the checker and tests make no network calls.

## Assess a real feature without changing the policy

The supplied `assessments/salesforce-assessment.json` and `assessments/servicenow-assessment.json` are deliberately incomplete. They use JSON to keep exactly three YAML definition files. The loader also accepts YAML assessments with the same shape.

To create another assessment:

```bash
python saas_enablement.py init salesforce --output assessments/my-salesforce.json
python saas_enablement.py init servicenow --output assessments/my-servicenow.json
```

The command never overwrites an existing file and does **not** fill in passing settings. Scope and applicable settings start as `null`; evidence starts `pending`. Vendor-specific capabilities unsupported by that overlay start `false`; the other capability flags need an explicit decision.

Fill in actual scope, capability flags, declared settings, and evidence references. Leave unsupported or unresolved requirements unknown rather than inventing a setting or an approval.

```bash
python saas_enablement.py validate assessments/my-salesforce.json --report reports/salesforce-review.md
python saas_enablement.py validate assessments/my-servicenow.json --report reports/servicenow-review.md
```

A draft assessment is expected to return **exit code 1**, showing unresolved scope/settings. Reports are generated even when declarations are blocked.

| Result | Meaning |
|---|---|
| PASS | The typed declaration matches the proposed requirement; not proof it is implemented |
| FAIL | A declared value contradicts a required setting or capability rule |
| UNKNOWN | Required scope, capability, or setting is absent/unresolved |
| PENDING | An applicable evidence-only control needs independent review |
| NOT_APPLICABLE | Every trigger for a conditional control is explicitly false |

`applies_when` uses **OR** semantics: any enabled listed capability activates that control. An unknown capability is not a waiver. There is no user-provided `skip`, `approved`, or `not_applicable` override. The checker does not discover undeclared capabilities in the real tenant.

A missing mandatory declaration blocks conformance. Missing implementation evidence remains visibly outstanding even when declarations conform. Evidence can be `pending` or `claimed` with references; it is never self-verified. References are not fetched. **Implementation assurance always remains UNVERIFIED, and `authorizes_release` remains false.**

Exit codes: **0** completed definition check/conforming declarations or successful draft creation; **1** failed/unknown assessment declarations; **2** malformed input, changed/unreviewed definitions, invalid usage, or operational error. These are not release gates.

## What the unit tests prove

The suite checks definitions, references, policy-change detection, typed settings, positive declarations, unsafe/missing declarations, conditional applicability, evidence boundaries, parser safety, CLI behavior, and report generation.

Independent literal regression expectations include access control, no training/reuse, Apex field security, model masking assumptions, agent execution identity, effective opt-out, overflow restrictions, and logging-versus-blocking behavior.

`tests/fixtures/synthetic-*.json` are **unit-test fixtures, not preapproved real-tenant examples**. They deliberately exercise optional capability controls. Their passing declaration results retain pending implementation evidence and do not authorize those capabilities.

Results: `reports/test-run.txt` and `reports/junit.xml`. Test counts measure executed software test cases, not security/compliance coverage percentages.

## Policy changes and integration with the earlier ABC repository

**This is a standalone SaaS add-on with schema `saas-enablement/1.0`.** It is intentionally richer than the earlier generic ABC pattern format. Keep this complete directory under your existing repository, for example `saas-enablement/`, and run its own checker.

Do **not** drop the three YAMLs into the earlier `patterns/` folder and expect the earlier `validate.py` to accept them. No previous files or tests have been modified.

`policy-snapshot.json` fingerprints the shipped policy definitions. Deleting a control or changing a requirement fails the integrity check until an independently reviewed policy change updates the snapshot and relevant tests. The snapshot is a **change-detection aid, not a signature, authorization, or defense against someone who can edit both policy and validator/tests**.

Use protected reviews for YAML, snapshot, checker, and tests. A legitimate policy revision requires reviewing the change, updating independent regression expectations, deliberately updating the snapshot, and rerunning the suite. Do not refresh it merely to suppress a failure. Changes to tenant declarations belong in assessments, not in the requirements.

AI Security owns the complete assessment. The application team supplies facts/evidence and remediation. Security Authority endorses the bounded assessment; separate risk acceptance, privacy/legal/third-party/model-risk decisions and release authorization remain with their designated owners.

## Remaining limits

This is a comprehensive proposed starting catalog, not a guarantee that every control needed by every license, feature, industry, region, or organization is included. Live tenant tests, vendor evidence, privacy/legal interpretation, data-owner decisions, and authorized approval are still required. There is no live configuration collection, external scanning, deployment, UI, diagramming, or API connection in this package.
