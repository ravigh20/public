# Working instructions

- The three top-level YAML files define draft security policy, not tenant implementation facts.
- Read README.md and preserve source/control identifiers and baseline dependencies.
- Tenant declarations belong under assessments/. Do not fill unknown values from required settings.
- Run `python saas_enablement.py check` and `python -m pytest -q` after approved changes.
- Do not weaken controls, regenerate snapshots, delete negative tests, or invent evidence merely to make checks pass.
- Review policy changes independently before deliberately updating the snapshot and regression cases.
- Evidence remains pending/claimed, implementation remains unverified, and no local result authorizes release.
- Do not deploy, fetch evidence URLs, call a tenant API, commit, push, or alter unrelated files without an explicit request.
