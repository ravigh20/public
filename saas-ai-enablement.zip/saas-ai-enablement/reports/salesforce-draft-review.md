# salesforce AI enablement declaration review

**Declaration conformance:** BLOCKED
**Implementation assurance: UNVERIFIED. Release authorization: false.**

Checks cover logical declarations only; evidence references are not fetched, verified, or approved.

## Declaration results

| Control | Field | Required | Declared | Result | Remediation |
|---|---|---|---|---|---|
| "SCOPE" | "scope.audience" | "feature-scoped value" | null | "UNKNOWN" | "Identify the actual tenant, feature and processing scope; do not assume a whole product is approved." |
| "SCOPE" | "scope.feature_names" | "feature-scoped value" | null | "UNKNOWN" | "Identify the actual tenant, feature and processing scope; do not assume a whole product is approved." |
| "SCOPE" | "scope.license_or_sku" | "feature-scoped value" | null | "UNKNOWN" | "Identify the actual tenant, feature and processing scope; do not assume a whole product is approved." |
| "SCOPE" | "scope.model_routes" | "feature-scoped value" | null | "UNKNOWN" | "Identify the actual tenant, feature and processing scope; do not assume a whole product is approved." |
| "SCOPE" | "scope.owner_role" | "feature-scoped value" | null | "UNKNOWN" | "Identify the actual tenant, feature and processing scope; do not assume a whole product is approved." |
| "SCOPE" | "scope.processing_regions" | "feature-scoped value" | null | "UNKNOWN" | "Identify the actual tenant, feature and processing scope; do not assume a whole product is approved." |
| "SCOPE" | "scope.release_or_version" | "feature-scoped value" | null | "UNKNOWN" | "Identify the actual tenant, feature and processing scope; do not assume a whole product is approved." |
| "SCOPE" | "scope.tenant_id" | "feature-scoped value" | null | "UNKNOWN" | "Identify the actual tenant, feature and processing scope; do not assume a whole product is approved." |
| "SCOPE" | "capabilities.retrieval" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SCOPE" | "capabilities.agents" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SCOPE" | "capabilities.write_actions" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SCOPE" | "capabilities.external_connectors" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SCOPE" | "capabilities.custom_code" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SCOPE" | "capabilities.mcp" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SCOPE" | "capabilities.external_users" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SCOPE" | "capabilities.multimodal" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SCOPE" | "capabilities.data_cloud" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SCOPE" | "capabilities.custom_models" | "explicit true or false" | null | "UNKNOWN" | "Confirm whether this capability is in scope; omission is not non-applicability." |
| "SAAS-GOV-001" | "settings.feature_inventory_complete" | true | null | "UNKNOWN" | "Record feature/SKU, environment, region, channels, provider routes, dependencies, capabilities, pilot size and accountable roles before enablement." |
| "SAAS-GOV-001" | "settings.unreviewed_ai_features_enabled" | false | null | "UNKNOWN" | "Record feature/SKU, environment, region, channels, provider routes, dependencies, capabilities, pilot size and accountable roles before enablement." |
| "SAAS-GOV-002" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-GOV-003" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-GOV-004" | "settings.staged_rollout_required" | true | null | "UNKNOWN" | "Use synthetic or approved sanitized test data, peer-reviewed changes and a staged activation plan with rollback criteria." |
| "SAAS-GOV-004" | "settings.production_data_in_unapproved_test_tenants" | false | null | "UNKNOWN" | "Use synthetic or approved sanitized test data, peer-reviewed changes and a staged activation plan with rollback criteria." |
| "SAAS-GOV-005" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-GOV-006" | "settings.autonomous_high_impact_decisions_enabled" | false | null | "UNKNOWN" | "Train users, label AI content where relevant and require authorized human review before business actions or external publication. Route high-impact use to relevant governance owners." |
| "SAAS-GOV-006" | "settings.human_review_before_business_action" | true | null | "UNKNOWN" | "Train users, label AI content where relevant and require authorized human review before business actions or external publication. Route high-impact use to relevant governance owners." |
| "SAAS-IAM-001" | "settings.enterprise_sso_enforced" | true | null | "UNKNOWN" | "Apply the existing approved IdP and conditional access. Constrain and monitor documented break-glass accounts; test alternate sign-in and API channels." |
| "SAAS-IAM-001" | "settings.human_mfa_required" | true | null | "UNKNOWN" | "Apply the existing approved IdP and conditional access. Constrain and monitor documented break-glass accounts; test alternate sign-in and API channels." |
| "SAAS-IAM-001" | "settings.unmanaged_local_ai_accounts_allowed" | false | null | "UNKNOWN" | "Apply the existing approved IdP and conditional access. Constrain and monitor documented break-glass accounts; test alternate sign-in and API channels." |
| "SAAS-IAM-002" | "settings.ai_entitlements_restricted" | true | null | "UNKNOWN" | "Separate users, builders, connector owners and tenant administrators; review direct assignments and privilege-bearing permission bundles." |
| "SAAS-IAM-002" | "settings.ai_runtime_admin_privileges" | false | null | "UNKNOWN" | "Separate users, builders, connector owners and tenant administrators; review direct assignments and privilege-bearing permission bundles." |
| "SAAS-IAM-003" | "settings.ai_deprovisioning_includes_tokens" | true | null | "UNKNOWN" | "Connect approved provisioning/deprovisioning processes and inventory nonhuman identities, direct grants and cached authorizations." |
| "SAAS-IAM-003" | "settings.ai_access_recertification_required" | true | null | "UNKNOWN" | "Connect approved provisioning/deprovisioning processes and inventory nonhuman identities, direct grants and cached authorizations." |
| "SAAS-IAM-004" | "settings.security_changes_peer_reviewed" | true | null | "UNKNOWN" | "Use time-limited privileged access where available; otherwise document an approved equivalent with monitoring and revocation. Separate approvers from implementers." |
| "SAAS-IAM-004" | "settings.privileged_ai_changes_audited" | true | null | "UNKNOWN" | "Use time-limited privileged access where available; otherwise document an approved equivalent with monitoring and revocation. Separate approvers from implementers." |
| "SAAS-IAM-005" | "settings.session_controls_defined" | true | null | "UNKNOWN" | "Review session lifetime/revocation, browser/mobile/desktop channels and DLP. Treat voice, screen capture and attachments as additional data routes." |
| "SAAS-IAM-005" | "settings.unapproved_ai_channels_enabled" | false | null | "UNKNOWN" | "Review session lifetime/revocation, browser/mobile/desktop channels and DLP. Treat voice, screen capture and attachments as additional data routes." |
| "SAAS-IAM-006" | "applies_when" | ["agents", "external_connectors", "write_actions"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-DAT-001" | "settings.prohibited_ai_data_classes" | ["PII", "SI", "HSI"] | null | "UNKNOWN" | "Inventory prompts, grounding, attachments, generated outputs, memory and logs. Do not assume existing SaaS data approval permits new AI processing. Change this draft restriction only through reviewed policy change." |
| "SAAS-DAT-001" | "settings.unclassified_ai_data_allowed" | false | null | "UNKNOWN" | "Inventory prompts, grounding, attachments, generated outputs, memory and logs. Do not assume existing SaaS data approval permits new AI processing. Change this draft restriction only through reviewed policy change." |
| "SAAS-DAT-002" | "settings.grounding_fields_allowlisted" | true | null | "UNKNOWN" | "Use explicit source/field allowlists and bounded history. Exclude secrets, confidential attachments and unrelated records before inference." |
| "SAAS-DAT-002" | "settings.unbounded_history_sent_to_model" | false | null | "UNKNOWN" | "Use explicit source/field allowlists and bounded history. Exclude secrets, confidential attachments and unrelated records before inference." |
| "SAAS-DAT-003" | "settings.source_authorization_preserved" | true | null | "UNKNOWN" | "Test object/table, field, record/document, tenant/domain and attachment boundaries including indirect retrieval paths and caches." |
| "SAAS-DAT-003" | "settings.cross_user_data_access_allowed" | false | null | "UNKNOWN" | "Test object/table, field, record/document, tenant/domain and attachment boundaries including indirect retrieval paths and caches." |
| "SAAS-DAT-004" | "settings.sensitive_content_controls_cover_selected_routes" | true | null | "UNKNOWN" | "Verify feature-specific DLP/masking coverage and ordering. Block or exclude unsupported fields/routes and validate both requests and outputs with representative test data." |
| "SAAS-DAT-004" | "settings.masking_assumed_from_platform_brand" | false | null | "UNKNOWN" | "Verify feature-specific DLP/masking coverage and ordering. Block or exclude unsupported fields/routes and validate both requests and outputs with representative test data." |
| "SAAS-DAT-005" | "settings.tls_certificate_validation_required" | true | null | "UNKNOWN" | "Use approved TLS and certificate validation; obtain vendor evidence for backend storage and internal model routes rather than assuming UI TLS covers all hops." |
| "SAAS-DAT-005" | "settings.plaintext_ai_integrations_allowed" | false | null | "UNKNOWN" | "Use approved TLS and certificate validation; obtain vendor evidence for backend storage and internal model routes rather than assuming UI TLS covers all hops." |
| "SAAS-DAT-006" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-DAT-007" | "settings.provider_training_on_customer_content" | false | null | "UNKNOWN" | "Verify contractual terms and effective tenant opt-out for each provider, environment and feedback program. Review tenant-specific learning separately; no fine-tuning is authorized here." |
| "SAAS-DAT-007" | "settings.product_improvement_data_sharing" | false | null | "UNKNOWN" | "Verify contractual terms and effective tenant opt-out for each provider, environment and feedback program. Review tenant-specific learning separately; no fine-tuning is authorized here." |
| "SAAS-DAT-007" | "settings.unreviewed_feedback_learning_enabled" | false | null | "UNKNOWN" | "Verify contractual terms and effective tenant opt-out for each provider, environment and feedback program. Review tenant-specific learning separately; no fine-tuning is authorized here." |
| "SAAS-DAT-008" | "settings.third_party_model_content_retention" | "none" | null | "UNKNOWN" | "Obtain route-specific retention commitments and enumerate abuse monitoring, support, fallback and debug exceptions. Unsupported terms are a blocking gap, not assumed zero retention." |
| "SAAS-DAT-008" | "settings.retention_claim_scope_documented" | true | null | "UNKNOWN" | "Obtain route-specific retention commitments and enumerate abuse monitoring, support, fallback and debug exceptions. Unsupported terms are a blocking gap, not assumed zero retention." |
| "SAAS-DAT-009" | "settings.optional_raw_content_logging_enabled" | false | null | "UNKNOWN" | "Disable optional raw content/debug logging. For mandatory vendor-held logs, determine content, location, access and deletion support and obtain a scoped decision before enablement." |
| "SAAS-DAT-009" | "settings.retention_and_legal_hold_schedule_defined" | true | null | "UNKNOWN" | "Disable optional raw content/debug logging. For mandatory vendor-held logs, determine content, location, access and deletion support and obtain a scoped decision before enablement." |
| "SAAS-DAT-010" | "settings.processing_regions_allowlisted" | true | null | "UNKNOWN" | "Record exact route/region commitments and failover behavior. Restrict unapproved overflow rather than assuming the tenant hosting region determines model execution." |
| "SAAS-DAT-010" | "settings.unapproved_region_fallback_allowed" | false | null | "UNKNOWN" | "Record exact route/region commitments and failover behavior. Restrict unapproved overflow rather than assuming the tenant hosting region determines model execution." |
| "SAAS-DAT-011" | "settings.derived_data_deletion_process_defined" | true | null | "UNKNOWN" | "Define verified deletion windows and known backup/legal-hold limits; test source removal and entitlement changes against retrieval." |
| "SAAS-DAT-011" | "settings.revoked_sources_remain_retrievable" | false | null | "UNKNOWN" | "Define verified deletion windows and known backup/legal-hold limits; test source removal and entitlement changes against retrieval." |
| "SAAS-DAT-012" | "settings.cross_tenant_context_reuse_allowed" | false | null | "UNKNOWN" | "Test cross-user/context leakage and obtain vendor evidence for model-serving and storage separation. Conversation identifiers are not an authorization control." |
| "SAAS-DAT-012" | "settings.shared_user_conversation_memory_allowed" | false | null | "UNKNOWN" | "Test cross-user/context leakage and obtain vendor evidence for model-serving and storage separation. Conversation identifiers are not an authorization control." |
| "SAAS-DAT-013" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-NET-001" | "settings.unapproved_ai_endpoints_allowed" | false | null | "UNKNOWN" | "Use approved domains, transport, session controls and available tenant IP/network restrictions. Require private connectivity only where policy requires it and the specific route supports it." |
| "SAAS-NET-001" | "settings.customer_network_controls_bypassed" | false | null | "UNKNOWN" | "Use approved domains, transport, session controls and available tenant IP/network restrictions. Require private connectivity only where policy requires it and the specific route supports it." |
| "SAAS-NET-002" | "applies_when" | ["external_connectors", "agents", "write_actions"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-NET-003" | "settings.inline_credentials_allowed" | false | null | "UNKNOWN" | "Use approved OAuth/service auth, restrict audiences/scopes and separate environments; avoid credential passthrough or shared administrator tokens." |
| "SAAS-NET-003" | "settings.integration_credentials_scoped" | true | null | "UNKNOWN" | "Use approved OAuth/service auth, restrict audiences/scopes and separate environments; avoid credential passthrough or shared administrator tokens." |
| "SAAS-NET-003" | "settings.credential_rotation_and_revocation_defined" | true | null | "UNKNOWN" | "Use approved OAuth/service auth, restrict audiences/scopes and separate environments; avoid credential passthrough or shared administrator tokens." |
| "SAAS-NET-004" | "applies_when" | ["external_connectors", "write_actions", "custom_code"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-AI-001" | "settings.input_protection_coverage_documented" | true | null | "UNKNOWN" | "Map native protections to required outcomes, record unsupported surfaces and prevent unreviewed direct model calls or bypass routes." |
| "SAAS-AI-001" | "settings.output_protection_coverage_documented" | true | null | "UNKNOWN" | "Map native protections to required outcomes, record unsupported surfaces and prevent unreviewed direct model calls or bypass routes." |
| "SAAS-AI-001" | "settings.unreviewed_guardrail_bypass_allowed" | false | null | "UNKNOWN" | "Map native protections to required outcomes, record unsupported surfaces and prevent unreviewed direct model calls or bypass routes." |
| "SAAS-AI-002" | "settings.untrusted_content_treated_as_data" | true | null | "UNKNOWN" | "Combine available detection with deterministic authorization, destination restrictions and human approval. Include multi-turn and cross-agent negative tests." |
| "SAAS-AI-002" | "settings.llm_text_can_override_authorization" | false | null | "UNKNOWN" | "Combine available detection with deterministic authorization, destination restrictions and human approval. Include multi-turn and cross-agent negative tests." |
| "SAAS-AI-003" | "settings.model_output_auto_execution_allowed" | false | null | "UNKNOWN" | "Encode HTML/Markdown, validate links and file types and review generated code/queries. Never automatically execute model output as code or instructions." |
| "SAAS-AI-003" | "settings.generated_content_sanitized" | true | null | "UNKNOWN" | "Encode HTML/Markdown, validate links and file types and review generated code/queries. Never automatically execute model output as code or instructions." |
| "SAAS-AI-004" | "settings.material_ai_output_human_review_required" | true | null | "UNKNOWN" | "Require evidence-aware review for high-impact outputs, handle uncertainty and route unsupported requests to a safe human/non-AI fallback." |
| "SAAS-AI-004" | "settings.unverified_ai_output_treated_as_authoritative" | false | null | "UNKNOWN" | "Require evidence-aware review for high-impact outputs, handle uncertainty and route unsupported requests to a safe human/non-AI fallback." |
| "SAAS-AI-005" | "settings.secrets_in_prompts_allowed" | false | null | "UNKNOWN" | "Restrict prompt editing and exports, version templates and keep enforcement in deterministic policy rather than hidden text." |
| "SAAS-AI-005" | "settings.prompt_text_used_as_access_control" | false | null | "UNKNOWN" | "Restrict prompt editing and exports, version templates and keep enforcement in deterministic policy rather than hidden text." |
| "SAAS-AI-006" | "applies_when" | ["agents"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-AI-007" | "applies_when" | ["write_actions"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-AI-008" | "applies_when" | ["write_actions"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-AI-009" | "applies_when" | ["agents"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-AI-010" | "applies_when" | ["agents"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-AI-011" | "settings.required_protection_failure_behavior" | "block_or_safe_non_ai_fallback" | null | "UNKNOWN" | "Verify actual feature failure behavior. Restrict or disable unsupported functionality rather than inventing a fail-closed vendor toggle." |
| "SAAS-AI-011" | "settings.silent_unguarded_fallback_allowed" | false | null | "UNKNOWN" | "Verify actual feature failure behavior. Restrict or disable unsupported functionality rather than inventing a fail-closed vendor toggle." |
| "SAAS-RAG-001" | "applies_when" | ["retrieval"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-RAG-002" | "applies_when" | ["retrieval"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-RAG-003" | "applies_when" | ["retrieval"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-INT-001" | "applies_when" | ["external_connectors"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-INT-002" | "applies_when" | ["custom_code"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-INT-003" | "applies_when" | ["mcp"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-MON-001" | "settings.ai_security_events_captured" | true | null | "UNKNOWN" | "Confirm feature/licensing support, correlation IDs, integrity and export for access, admin, connector, DLP and action events." |
| "SAAS-MON-001" | "settings.actor_and_effective_identity_traceable" | true | null | "UNKNOWN" | "Confirm feature/licensing support, correlation IDs, integrity and export for access, admin, connector, DLP and action events." |
| "SAAS-MON-002" | "settings.ai_security_events_exported_to_monitoring" | true | null | "UNKNOWN" | "Detect anomalous access, export, injection, connector grants, configuration changes and cost spikes; monitor log-export health." |
| "SAAS-MON-002" | "settings.ai_alert_owner_assigned" | true | null | "UNKNOWN" | "Detect anomalous access, export, injection, connector grants, configuration changes and cost spikes; monitor log-export health." |
| "SAAS-MON-003" | "settings.ai_log_access_restricted" | true | null | "UNKNOWN" | "Restrict readers/exporters, redact sensitive fields, apply retention and legal holds and separate security metadata from raw conversation content." |
| "SAAS-MON-003" | "settings.ai_logs_redacted_before_export" | true | null | "UNKNOWN" | "Restrict readers/exporters, redact sensitive fields, apply retention and legal holds and separate security metadata from raw conversation content." |
| "SAAS-MON-004" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-OPS-001" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-OPS-002" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-OPS-003" | "settings.ai_emergency_disablement_defined" | true | null | "UNKNOWN" | "Disable the relevant features and triggers, revoke credentials and address active/queued tasks; retain the core non-AI service where safely possible." |
| "SAAS-OPS-003" | "settings.disablement_covers_background_and_api_paths" | true | null | "UNKNOWN" | "Disable the relevant features and triggers, revoke credentials and address active/queued tasks; retain the core non-AI service where safely possible." |
| "SAAS-OPS-004" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-OPS-005" | "settings.ai_usage_limits_defined" | true | null | "UNKNOWN" | "Configure available quotas/budgets, alert owners and safe stopping behavior; prevent denial of service through oversized attachments or repeated requests." |
| "SAAS-OPS-005" | "settings.ai_consumption_alerts_enabled" | true | null | "UNKNOWN" | "Configure available quotas/budgets, alert owners and safe stopping behavior; prevent denial of service through oversized attachments or repeated requests." |
| "SAAS-OPS-006" | "settings.material_ai_changes_trigger_review" | true | null | "UNKNOWN" | "Monitor vendor notices and default-on changes. Use version-bound promotion, drift review and a defined reassessment cadence." |
| "SAAS-OPS-006" | "settings.unreviewed_default_on_features_allowed" | false | null | "UNKNOWN" | "Monitor vendor notices and default-on changes. Use version-bound promotion, drift review and a defined reassessment cadence." |
| "SAAS-OPS-007" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-PRV-001" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SAAS-CHN-001" | "applies_when" | ["external_users"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SAAS-CHN-002" | "applies_when" | ["multimodal"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-001" | "settings.salesforce_feature_org_matrix_complete" | true | null | "UNKNOWN" | "Inventory Prompt Builder, agents, Data Cloud/Data 360 dependencies, model routes, standard/custom actions and UI/API entry points actually selected. A product name is not an approval scope." |
| "SF-001" | "settings.salesforce_unreviewed_features_enabled" | false | null | "UNKNOWN" | "Inventory Prompt Builder, agents, Data Cloud/Data 360 dependencies, model routes, standard/custom actions and UI/API entry points actually selected. A product name is not an approval scope." |
| "SF-002" | "settings.salesforce_ai_permissions_least_privilege" | true | null | "UNKNOWN" | "Review effective profiles, permission sets/groups and integration users; separate prompt/agent builders, deployers, operators and users." |
| "SF-002" | "settings.salesforce_ai_builders_can_self_approve" | false | null | "UNKNOWN" | "Review effective profiles, permission sets/groups and integration users; separate prompt/agent builders, deployers, operators and users." |
| "SF-003" | "applies_when" | ["agents"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-004" | "settings.salesforce_object_field_record_access_enforced" | true | null | "UNKNOWN" | "Review permission sets, sharing rules, ownership and Apex/Flow/action behavior; test field and record denials in generated summaries and tool responses." |
| "SF-004" | "settings.salesforce_denied_fields_in_grounding_allowed" | false | null | "UNKNOWN" | "Review permission sets, sharing rules, ownership and Apex/Flow/action behavior; test field and record denials in generated summaries and tool responses." |
| "SF-005" | "applies_when" | ["write_actions", "custom_code"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-006" | "applies_when" | ["custom_code"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-007" | "settings.salesforce_prompt_templates_reviewed" | true | null | "UNKNOWN" | "Version templates; review merge fields, grounding actions, retrieved attachments and dynamic context. Do not place secrets or business authorization only in instructions." |
| "SF-007" | "settings.salesforce_grounding_fields_minimized" | true | null | "UNKNOWN" | "Version templates; review merge fields, grounding actions, retrieved attachments and dynamic context. Do not place secrets or business authorization only in instructions." |
| "SF-008" | "settings.salesforce_trust_layer_feature_coverage_documented" | true | null | "UNKNOWN" | "Use the current feature documentation and tenant tests. Do not infer masking availability or equivalence across agent actions, Prompt Builder and Models API from a general Trust Layer overview." |
| "SF-008" | "settings.salesforce_masking_assumed_for_all_features" | false | null | "UNKNOWN" | "Use the current feature documentation and tenant tests. Do not infer masking availability or equivalence across agent actions, Prompt Builder and Models API from a general Trust Layer overview." |
| "SF-009" | "settings.salesforce_provider_and_platform_retention_separated" | true | null | "UNKNOWN" | "Document which party retains which records and under what term. Include diagnostics, optional feedback and custom provider routes; a partner retention agreement does not clear other stores." |
| "SF-009" | "settings.salesforce_custom_provider_terms_reviewed" | true | null | "UNKNOWN" | "Document which party retains which records and under what term. Include diagnostics, optional feedback and custom provider routes; a partner retention agreement does not clear other stores." |
| "SF-010" | "applies_when" | ["data_cloud"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-011" | "applies_when" | ["retrieval"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-012" | "applies_when" | ["retrieval"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-013" | "applies_when" | ["external_connectors"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-014" | "applies_when" | ["external_users"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-015" | "applies_when" | ["write_actions"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-016" | "settings.salesforce_ai_event_coverage_documented" | true | null | "UNKNOWN" | "Assess available AI audit/session tracing, Setup changes and Event Monitoring as applicable. Document coverage, storage, readers, retention and export limitations instead of assuming a license includes them." |
| "SF-016" | "settings.salesforce_ai_log_content_access_restricted" | true | null | "UNKNOWN" | "Assess available AI audit/session tracing, Setup changes and Event Monitoring as applicable. Document coverage, storage, readers, retention and export limitations instead of assuming a license includes them." |
| "SF-017" | "applies_when" | ["custom_models", "custom_code"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-018" | "settings.salesforce_ai_changes_regression_tested" | true | null | "UNKNOWN" | "Use controlled versions and sandbox tests with approved data; recheck entitlement, leakage, action and protection paths after feature/model releases." |
| "SF-018" | "settings.salesforce_unreviewed_ai_production_promotion" | false | null | "UNKNOWN" | "Use controlled versions and sandbox tests with approved data; recheck entitlement, leakage, action and protection paths after feature/model releases." |
| "SF-019" | "settings.salesforce_ai_disablement_all_entry_points" | true | null | "UNKNOWN" | "Document exact tenant-specific disablement steps and treatment of active sessions and queued actions; exercise credential revocation and safe manual fallback." |
| "SF-019" | "settings.salesforce_ai_active_job_containment_defined" | true | null | "UNKNOWN" | "Document exact tenant-specific disablement steps and treatment of active sessions and queued actions; exercise credential revocation and safe manual fallback." |
| "SF-020" | "evidence" | "independent evidence review" | null | "PENDING" | "This control is not automatable by comparing configuration declarations." |
| "SF-021" | "applies_when" | ["mcp", "custom_code"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |
| "SF-022" | "applies_when" | ["agents"] | null | "UNKNOWN" | "Resolve capability scope before excluding or assessing this control." |

## Evidence review remains outstanding

Pending and claimed references both require independent review. No evidence content is embedded.

| Control | Submitted state | Required evidence |
|---|---|---|
| SAAS-GOV-001 | pending | ["Feature inventory, bounded intake and approved change scope; record unknown SKUs/providers as gaps."] |
| SAAS-GOV-002 | pending | ["Assessment ownership matrix, signed assessment reference, bounded SA endorsement and separate domain approvals where required."] |
| SAAS-GOV-003 | pending | ["Inheritance matrix and delta assessment with explicit vendor/customer/shared responsibility."] |
| SAAS-GOV-004 | pending | ["Pilot plan, test-tenant access review, rollout group membership and rollback criteria."] |
| SAAS-GOV-005 | pending | ["Decision register, exception owner/expiry/compensating evidence and material-change review history."] |
| SAAS-GOV-006 | pending | ["Acceptable-use guidance, user training and documented review points for the intended business process."] |
| SAAS-IAM-001 | pending | ["SSO/MFA policy and denied-access tests for non-entitled users and alternate sign-in paths."] |
| SAAS-IAM-002 | pending | ["Feature role/permission-set export and positive/negative access tests."] |
| SAAS-IAM-003 | pending | ["Leaver test showing feature, session, connector and cached access revocation; access review schedule."] |
| SAAS-IAM-004 | pending | ["Admin role inventory, privileged-access procedure and sample reviewed configuration change."] |
| SAAS-IAM-005 | pending | ["Session/channel settings, unmanaged-device decision and session-revocation test."] |
| SAAS-DAT-001 | pending | ["Data-flow classification, data-owner decision and test records for prohibited classes."] |
| SAAS-DAT-002 | pending | ["Prompt/grounding field map and sanitized request examples."] |
| SAAS-DAT-003 | pending | ["Two-user denied-record/field tests covering search, summaries, citations and API/tool paths."] |
| SAAS-DAT-004 | pending | ["Per-route masking/DLP configuration, detection tests and documented coverage gaps."] |
| SAAS-DAT-005 | pending | ["Endpoint tests and feature-scoped vendor encryption/storage evidence."] |
| SAAS-DAT-006 | pending | ["Encryption coverage map, key-management evidence and customer-managed-key support/limitation decision."] |
| SAAS-DAT-007 | pending | ["Feature/provider contractual terms, effective opt-out confirmations and feedback configuration."] |
| SAAS-DAT-008 | pending | ["Provider commitments plus a separate SaaS store-by-store retention schedule."] |
| SAAS-DAT-009 | pending | ["Storage inventory including histories, prompts, responses, traces, feedback and incident evidence."] |
| SAAS-DAT-010 | pending | ["Feature-level data-location map, subprocessor locations and regional fallback/overflow decision."] |
| SAAS-DAT-011 | pending | ["Deletion/revocation test plus vendor backup, recovery and legal-hold limitations."] |
| SAAS-DAT-012 | pending | ["Tenant-isolation assurance and cross-user/session adversarial tests."] |
| SAAS-DAT-013 | pending | ["Support-access controls, access-event availability and contractual human-access terms."] |
| SAAS-NET-001 | pending | ["Approved endpoint inventory and connectivity decision for browser, API and connector paths."] |
| SAAS-NET-003 | pending | ["Credential-reference inventory, redacted scope export and revocation test; never attach secret values."] |
| SAAS-AI-001 | pending | ["Per-feature protection matrix and request/response/custom-route tests."] |
| SAAS-AI-002 | pending | ["Injection test plan and results across all in-scope input and retrieval surfaces."] |
| SAAS-AI-003 | pending | ["Output rendering/escaping tests and downstream input-validation controls."] |
| SAAS-AI-004 | pending | ["Source fidelity tests, hallucination/error handling and business review procedure."] |
| SAAS-AI-005 | pending | ["Redacted prompt review, editor permissions and prompt-extraction impact assessment."] |
| SAAS-AI-011 | pending | ["Timeout/outage tests and vendor evidence for the required protection boundary."] |
| SAAS-MON-001 | pending | ["Feature event coverage matrix and sanitized sample events for denied access and an action."] |
| SAAS-MON-002 | pending | ["Redacted event received by SIEM, alert rule tests and export failure runbook."] |
| SAAS-MON-003 | pending | ["Log-reader roles, redacted samples, retention settings and audit integrity evidence."] |
| SAAS-MON-004 | pending | ["Feature/version-bound test results, findings, remediation, accountable reviewer and evidence freshness."] |
| SAAS-OPS-001 | pending | ["Scoped assurance package, subprocessor inventory and unresolved risk/remediation register."] |
| SAAS-OPS-002 | pending | ["Joint incident runbook, vendor contact/escalation terms and tabletop outcome."] |
| SAAS-OPS-003 | pending | ["Authorized operator runbook and disablement/revocation exercise covering active jobs."] |
| SAAS-OPS-004 | pending | ["AI dependency map, vendor SLA/recovery evidence, backup/restore responsibility and non-AI continuity exercise."] |
| SAAS-OPS-005 | pending | ["Limit settings, oversize/rate-limit tests and cost-alert routing."] |
| SAAS-OPS-006 | pending | ["Change triggers, review cadence, vendor notice handling and configuration comparison."] |
| SAAS-OPS-007 | pending | ["Exit checklist, retention/legal-hold decision, credential revocation and vendor deletion commitments."] |
| SAAS-PRV-001 | pending | ["Feature-scoped privacy/legal/model-risk screening and required decisions; no blanket compliance assertion."] |
| SF-001 | pending | ["Org/feature/SKU matrix, selected functionality and release-specific capability evidence."] |
| SF-002 | pending | ["Effective permission export and unauthorized-user/builder denial tests."] |
| SF-004 | pending | ["Object/field/sharing configuration plus two-user negative retrieval and action tests."] |
| SF-007 | pending | ["Redacted templates, builder permissions, grounding field inventory and injection tests."] |
| SF-008 | pending | ["Feature/route capability matrix, observed configuration and representative DLP/guardrail tests."] |
| SF-009 | pending | ["Route-specific contractual evidence and Salesforce AI storage/retention inventory."] |
| SF-016 | pending | ["Feature/license event matrix, sanitized samples received centrally and retention/deletion configuration."] |
| SF-018 | pending | ["Promotion record and feature-version-bound security regression results."] |
| SF-019 | pending | ["Org-specific disablement runbook and exercise results."] |
| SF-020 | pending | ["Feature/store/key coverage map and vendor confirmation for unsupported surfaces."] |
