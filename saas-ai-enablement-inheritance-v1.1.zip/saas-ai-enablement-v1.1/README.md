# ABC — SaaS AI Enablement Security Controls

**Three YAML definitions. One shared baseline, inherited by vendor profiles with product/feature-specific additions.**

This package defines proposed requirements for enabling AI within an existing SaaS platform. It covers traditional solution security and AI-specific risks, while separating customer configuration, vendor responsibility, and independent evidence review.

## Files to start with

| File | Purpose | Controls |
|---|---|---:|
| `saas-ai-enablement-baseline.yaml` | Shared SaaS AI security requirements | 60 |
| `salesforce-ai-enablement.yaml` | Salesforce-specific implementation requirements, inheriting the baseline | 22 additional |
| `service-now-ai-enablement.yaml` | ServiceNow-specific implementation requirements, inheriting the baseline | 24 additional |

There are **106 unique control definitions across 16 domains**. A Salesforce review includes up to **82 controls**; a ServiceNow review includes up to **84 controls**. Conditional requirements apply only to the declared capabilities. These numbers measure the catalog, not protection, compliance, or completeness of an assessment.

The baseline is written once. Each vendor file references its ID, version, and filename through `inherits`, with `inheritance_mode: additive_only`. Its additional controls map back through `supports_baseline`. It cannot replace or weaken the baseline.

## Inheritance and product/feature selection (v1.1)

**Effective requirements = applicable baseline controls + vendor platform controls + applicable vendor feature controls.**

- The baseline contains vendor-neutral controls only. It includes common conditional rules for retrieval, agents, integrations, and other capabilities; these are inherited when applicable.
- `salesforce-ai-enablement.yaml` and `service-now-ai-enablement.yaml` contain only their own additional control definitions, never copies of baseline controls.
- `platform_control_refs` identifies each vendor's generally applicable additions.
- `features` groups the remaining additions by named product/feature. Every additional control belongs to exactly one group or the platform set.
- Each group references control IDs defined once in that vendor file. Its `applies_when` must match the member controls, so the grouping cannot silently change applicability.
- In the separate assessment, `capabilities` declares which feature areas are enabled. Any true trigger applies its feature group. All false means not applicable; an unresolved trigger is UNKNOWN and blocks declaration conformance. The exact feature/SKU/release/instance still belongs in `scope`.

A representative excerpt from the Salesforce profile is:

```yaml
inherits:
  - id: ABC-SAAS-AI-ENABLEMENT-BASELINE
    version: '1.1'
    file: saas-ai-enablement-baseline.yaml
inheritance_mode: additive_only

features:
  prompt_builder:
    product: Prompt Builder
    name: Prompt templates and grounding
    applies_when: [prompt_builder]
    control_refs: [SF-007]
```

For a Salesforce review, set `capabilities.prompt_builder` to true, false, or null to declare that feature's scope. Enabling `capabilities.agents` applies both common baseline agent controls and the additional Agentforce controls. Turning optional features off never removes always-applicable baseline controls such as enterprise sign-in/MFA.

Feature groups are **local review labels**, not an exhaustive vendor SKU catalog, install instructions, or a claim that a named feature is licensed. Review the actual installed products and versions. Unknown/unlisted functionality requires a policy extension, not a convenient existing label.

**Control inheritance is not evidence inheritance.** Evidence and decisions remain scoped to the actual tenant, product, feature, configuration, release, and date. Reusing prior evidence requires checking that coverage remains valid.

### Inspect the resolved requirements

```bash
python saas_enablement.py resolve assessments/salesforce-assessment.json --output reports/salesforce-effective-controls.json
```

This materializes a review-only JSON view with each control's origin (`inherited_baseline`, `vendor_platform`, or `vendor_feature`), applicability, requirements, and evidence needs. It is not another editable policy source. The complete inherited set stays visible even when conditional controls are not applicable.

A draft produces the view but exits **1** for blocked/unknown declarations. A conforming declaration set exits **0** without granting approval. Existing outputs are not overwritten; use another name or deliberately remove an old generated output.

### Changes from the earlier package

This is an intentional **schema/version 1.1** revision. The 106 control definitions and 200 required-setting assertions are retained. The specific Prompt Builder control `SF-007` now correctly applies to the `prompt_builder` capability rather than all Salesforce AI features. All other control requirements are unchanged.

The shared baseline no longer owns vendor-specific flags (`data_cloud`, `domain_separation`, or `mid_server`). Each vendor profile owns its applicable additions. The assessment format keeps an explicit combined vocabulary; irrelevant vendor-only flags must be false.

Existing 1.0 assessments are not silently upgraded: create a new 1.1 draft and explicitly transfer reviewed scope/settings/evidence. Salesforce's new `prompt_builder` flag must be resolved, not assumed. The integrity snapshot was deliberately updated for this draft schema/organization change; this is not a security approval.

## Important boundaries

- These are **draft organizational requirements**, not verified settings or vendor assurances.
- `required_settings` contains **logical review assertions**. The keys are not Salesforce Metadata API fields or ServiceNow system property names. Do not upload these YAMLs into a tenant as configuration.
- Verify the exact feature, SKU, release, instance/org, model route, audience, processing region, and connector/tool selection. Availability varies; a required safeguard that is unsupported remains a gap.
- The conservative ABC data policy prohibits **PII, SI, and HSI** in AI inputs/outputs. This is a proposed organizational restriction, not a vendor prohibition. Changing the allowed classifications requires a reviewed policy decision.
- Customer content must not be reused for shared-model training or product improvement under the proposed baseline. No fine-tuning is authorized.
- Retrieval, agents, tools, write actions, external audiences, custom models, and persistent memory need feature-scoped review. A control describing an extension is not permission to enable it.
- SaaS-only review does **not** impose GAI AKS, Azure subscription, or customer-managed private endpoint requirements on vendor infrastructure.
- Passing local tests cannot establish deployment security, vendor behavior, evidence authenticity, or Security Authority approval.

## Security coverage

| Area | Coverage examples |
|---|---|
| Governance and scope | Feature inventory, responsibility, delta review, pilots, scoped exceptions, material change |
| Identity and access | SSO/MFA, entitlements, least privilege, administrators, joiner/mover/leaver, execution identity |
| Data protection | Classification, field minimization, row/record/field/source permissions, DLP, masking, tenant/session isolation |
| Cryptography and secrets | Complete-path encryption, key-coverage evidence, credential references, OAuth scopes, rotation/revocation |
| Privacy and lifecycle | No secondary reuse, provider versus platform retention, feedback, histories, deletion, legal hold, residency/overflow |
| Networks and integrations | Approved domains/routes, exfiltration/SSRF controls, APIs, webhooks, connectors, custom code, packages, MCP |
| AI-specific risks | Prompt injection, untrusted outputs, grounding, prompt secrecy limits, feature protection coverage, safe failure |
| Agents and actions | Tool allowlists, effective identity, delegated authority, per-action authorization, trusted approval, budgets, recovery, memory |
| Retrieval | Source integrity, query-time permissions, protected citations, revocation/deletion propagation |
| Monitoring and assurance | Audit events, SIEM visibility, protected logs, feature-scoped positive/negative implementation tests |
| Operations | Supplier review, incident handling, disablement, recovery/manual fallback, consumption, change control, offboarding |
| Specialized scope | External/guest channels, multimodal inputs, privacy/legal/model-risk reviews |

Every control has an ID, requirement, implementation guidance, responsibility, applicability, evidence requirement, and a concrete negative scenario. **94 controls have declaration assertions and 12 are evidence-only.** Even the 94 need implementation evidence. The 106 negative scenarios are proposed tenant validation activities; this package does not execute those activities against either vendor.

See `CONTROL-INDEX.md` for the full control inventory without reading all YAML lines.

## Vendor-specific depth

### Salesforce

The overlay addresses feature/org entitlements, permission sets, execution identities, object/field/record permissions, Flow context, secure Apex, Prompt Builder, Trust Layer feature coverage, model-provider retention versus platform-held data, Data Cloud/Data 360 boundaries, search/Knowledge, connected apps and credentials, guest channels, write approvals, available audit events, custom model routes, encryption coverage, packages/MCP, and memory/feedback.

Specific review distinctions include:
- `with sharing` does not replace object/field permission enforcement in custom Apex.
- Do not infer every AI feature's masking/guardrail coverage from the Trust Layer name.
- Third-party-model zero-retention commitments are not a claim that the platform stores no AI histories, logs, or feedback.

### ServiceNow

The overlay addresses instance/plugin/skill inventory, administrative roles, table/record/field/attachment access, skill and agent invocation ACLs, effective run-as identity, dynamic-user role masking versus fixed AI-user privileges, delegated execution, supervised actions, Generative AI Controller/provider routes, effective data-sharing opt-out, overflow residency, Data Privacy channel coverage, Guardian behavior, Search/Knowledge, domain separation, IntegrationHub, optional MID Servers, custom scripts, portals, memory, logs, disablement, and clone/upgrade revalidation.

Specific review distinctions include:
- Permission to invoke an agent is not the same as the principal and privileges used when it executes.
- The cited Zurich security documentation distinguishes dynamic-user role masking from fixed AI-user permissions; verify the installed release.
- An opt-out request is not proof that opt-out is already effective on every instance.
- Guardian logging and Guardian blocking are different outcomes. Check coverage and actual enforcement for the selected skills.

Sources and version limitations from the preceding control catalog are retained inside the YAML and in `SOURCES.md`. This revision reorganizes inheritance and applicability; it is not a new audit of every vendor capability or documentation page. Most control requirements are proposed organizational policy, not quotations or claims about product defaults.

## Run the checks

Use Python 3.11 or later. From this directory:

```bash
python -m pip install -r requirements.txt
python saas_enablement.py check
python -m pytest -q
```

Windows PowerShell, without changing activation policy:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe saas_enablement.py check
.\.venv\Scripts\python.exe -m pytest -q
```

macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python saas_enablement.py check
.venv/bin/python -m pytest -q
```

The executed run used **Python 3.13.5 on Linux, PyYAML 6.0.3, and pytest 9.0.2**. Windows and other Python versions were not executed here. Top-level dependencies are pinned; this is not a transitive lockfile or vulnerability certification. Installation may require your approved package source; the checker and tests make no network calls.

## Assess a real feature without changing the policy

The supplied `assessments/salesforce-assessment.json` and `assessments/servicenow-assessment.json` are deliberately incomplete. They use JSON to keep exactly three YAML definition files. The loader also accepts YAML assessments with the same shape.

To create another assessment:

```bash
python saas_enablement.py init salesforce --output assessments/my-salesforce.json
python saas_enablement.py init servicenow --output assessments/my-servicenow.json
```

The command never overwrites an existing file and does **not** fill in passing settings. Scope and applicable settings start as `null`; evidence starts `pending`. Vendor-specific capabilities unsupported by that overlay start `false`; the other capability flags need an explicit decision.

Fill in actual scope, capability flags, declared settings, and evidence references. Leave unsupported or unresolved requirements unknown rather than inventing a setting or an approval.

```bash
python saas_enablement.py validate assessments/my-salesforce.json --report reports/salesforce-review.md
python saas_enablement.py validate assessments/my-servicenow.json --report reports/servicenow-review.md
```

A draft assessment is expected to return **exit code 1**, showing unresolved scope/settings. Reports are generated even when declarations are blocked.

| Result | Meaning |
|---|---|
| PASS | The typed declaration matches the proposed requirement; not proof it is implemented |
| FAIL | A declared value contradicts a required setting or capability rule |
| UNKNOWN | Required scope, capability, or setting is absent/unresolved |
| PENDING | An applicable evidence-only control needs independent review |
| NOT_APPLICABLE | Every trigger for a conditional control is explicitly false |

`applies_when` uses **OR** semantics: any enabled listed capability activates that control. An unknown capability is not a waiver. There is no user-provided `skip`, `approved`, or `not_applicable` override. The checker does not discover undeclared capabilities in the real tenant.

A missing mandatory declaration blocks conformance. Missing implementation evidence remains visibly outstanding even when declarations conform. Evidence can be `pending` or `claimed` with references; it is never self-verified. References are not fetched. **Implementation assurance always remains UNVERIFIED, and `authorizes_release` remains false.**

Exit codes: **0** completed definition check/conforming declarations, successful draft creation, or resolved conforming declarations; **1** failed/unknown assessment declarations; **2** malformed input, changed/unreviewed definitions, invalid usage, or operational error. These are not release gates.

## What the unit tests prove

The suite checks definitions, references, policy-change detection, typed settings, positive declarations, unsafe/missing declarations, conditional applicability, evidence boundaries, parser safety, CLI behavior, and report generation.

Independent literal regression expectations include access control, no training/reuse, Apex field security, model masking assumptions, agent execution identity, effective opt-out, overflow restrictions, and logging-versus-blocking behavior.

`tests/fixtures/synthetic-*.json` are **unit-test fixtures, not preapproved real-tenant examples**. They deliberately exercise optional capability controls. Their passing declaration results retain pending implementation evidence and do not authorize those capabilities.

Executed in this revision: **159 passing tests**, including 29 added inheritance/feature tests. Results: `reports/test-run.txt` and `reports/junit.xml`. Test counts measure executed software test cases, not security/compliance coverage percentages.

## Policy changes and integration with the earlier ABC repository

**This is a standalone SaaS add-on with schema `saas-enablement/1.1`.** It is intentionally richer than the earlier generic ABC pattern format. Keep this complete directory under your existing repository, for example `saas-enablement/`, and run its own checker.

Do **not** drop the three YAMLs into the earlier `patterns/` folder and expect the earlier `validate.py` to accept them. No previous files or tests have been modified.

`policy-snapshot.json` fingerprints the shipped policy definitions. Deleting a control or changing a requirement fails the integrity check until an independently reviewed policy change updates the snapshot and relevant tests. The snapshot is a **change-detection aid, not a signature, authorization, or defense against someone who can edit both policy and validator/tests**.

Use protected reviews for YAML, snapshot, checker, and tests. A legitimate policy revision requires reviewing the change, updating independent regression expectations, deliberately updating the snapshot, and rerunning the suite. Do not refresh it merely to suppress a failure. Changes to tenant declarations belong in assessments, not in the requirements.

AI Security owns the complete assessment. The application team supplies facts/evidence and remediation. Security Authority endorses the bounded assessment; separate risk acceptance, privacy/legal/third-party/model-risk decisions and release authorization remain with their designated owners.

## Remaining limits

This is a comprehensive proposed starting catalog, not a guarantee that every control needed by every license, feature, industry, region, or organization is included. Live tenant tests, vendor evidence, privacy/legal interpretation, data-owner decisions, and authorized approval are still required. There is no live configuration collection, external scanning, deployment, UI, diagramming, or API connection in this package.
