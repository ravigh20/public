"""Tests assess the files and checker, not either vendor's live tenant security."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import saas_enablement as app


@pytest.fixture(scope="session")
def docs():
    return app.load_definitions()


@pytest.fixture
def snapshot():
    return app.read(app.ROOT / "policy-snapshot.json")


def fixture(platform):
    # Committed synthetic inputs, not passing values populated by the validator.
    return app.read(app.ROOT / "tests" / "fixtures" / f"synthetic-{platform}.json")


# Expected security outcomes are literal regression cases, independent of candidate YAML.
CASES = [
    ("salesforce", "SAAS-IAM-001", "human_mfa_required", True, False),
    ("salesforce", "SAAS-DAT-001", "unclassified_ai_data_allowed", False, True),
    ("salesforce", "SAAS-DAT-003", "source_authorization_preserved", True, False),
    ("salesforce", "SAAS-DAT-007", "provider_training_on_customer_content", False, True),
    ("salesforce", "SAAS-DAT-007", "product_improvement_data_sharing", False, True),
    ("salesforce", "SF-004", "salesforce_object_field_record_access_enforced", True, False),
    ("salesforce", "SF-004", "salesforce_denied_fields_in_grounding_allowed", False, True),
    ("salesforce", "SF-006", "salesforce_apex_crud_fls_enforced", True, False),
    ("salesforce", "SF-006", "salesforce_apex_sharing_enforced", True, False),
    ("salesforce", "SF-008", "salesforce_masking_assumed_for_all_features", False, True),
    ("servicenow", "SN-003", "servicenow_table_record_field_acls_preserved", True, False),
    ("servicenow", "SN-005", "servicenow_run_as_identity_matrix_defined", True, False),
    ("servicenow", "SN-006", "servicenow_admin_ai_runtime_allowed", False, True),
    ("servicenow", "SN-008", "servicenow_business_tools_supervised", True, False),
    ("servicenow", "SN-010", "servicenow_product_improvement_sharing_enabled", False, True),
    ("servicenow", "SN-010", "servicenow_opt_out_effective_all_in_scope_instances", True, False),
    ("servicenow", "SN-011", "servicenow_unapproved_overflow_processing_allowed", False, True),
    ("servicenow", "SN-013", "servicenow_guardian_required_action", "block_or_safe_fallback", "log_only"),
    ("servicenow", "SN-013", "servicenow_logging_only_counted_as_blocking", False, True),
]


def field_result(result, cid, field):
    return [row for row in result["findings"] if row["control_id"] == cid and row["field"] == f"settings.{field}"]


def test_all_definition_files_are_valid(docs, snapshot):
    assert app.verify_documents(docs, snapshot) == []
    assert [len(d["controls"]) for d in docs.values()] == [60, 22, 24]
    assert sum(len(c["required_settings"]) for d in docs.values() for c in d["controls"]) == 200


@pytest.mark.parametrize("platform", ["salesforce", "servicenow"])
def test_good_declarations_never_imply_verified_security(platform, docs):
    result = app.evaluate(fixture(platform), docs)
    assert result["declaration_conformance"] == "PASS"
    assert result["implementation_assurance"] == "UNVERIFIED"
    assert result["authorizes_release"] is False
    assert result["counts"]["PENDING"] > 0
    assert all(row["status"] == "pending" for row in result["evidence_review"])


@pytest.mark.parametrize("platform,cid,key,required,bad", CASES)
def test_independent_control_floor(platform, cid, key, required, bad, docs):
    control = next(c for c in app.selected_controls(platform, docs) if c["id"] == cid)
    assert app.equal_value(control["required_settings"][key], required)
    result = app.evaluate(fixture(platform), docs)
    assert field_result(result, cid, key)[0]["status"] == "PASS"


@pytest.mark.parametrize("platform,cid,key,required,bad", CASES)
def test_bad_setting_reports_exact_control(platform, cid, key, required, bad, docs):
    data = fixture(platform)
    data["settings"][key] = bad
    result = app.evaluate(data, docs)
    assert field_result(result, cid, key)[0]["status"] == "FAIL"
    assert result["declaration_conformance"] == "BLOCKED"


@pytest.mark.parametrize("platform,cid,key,required,bad", CASES)
def test_missing_required_setting_is_unknown(platform, cid, key, required, bad, docs):
    data = fixture(platform)
    del data["settings"][key]
    result = app.evaluate(data, docs)
    assert field_result(result, cid, key)[0]["status"] == "UNKNOWN"
    assert result["declaration_conformance"] == "BLOCKED"


@pytest.mark.parametrize("platform,cid,key,required,bad", CASES)
def test_type_confusion_is_rejected(platform, cid, key, required, bad, docs):
    data = fixture(platform)
    data["settings"][key] = str(required).lower() if type(required) is bool else 1
    result = app.evaluate(data, docs)
    assert field_result(result, cid, key)[0]["status"] == "FAIL"


@pytest.mark.parametrize("platform", ["salesforce", "servicenow"])
def test_draft_has_no_fabricated_passing_settings(platform, docs):
    draft = app.new_assessment(platform, docs)
    assert all(value is None for value in draft["settings"].values())
    result = app.evaluate(draft, docs)
    assert result["declaration_conformance"] == "BLOCKED"
    assert result["counts"]["UNKNOWN"] > 0


@pytest.mark.parametrize("flag,expected", [(False, "NOT_APPLICABLE"), (None, "UNKNOWN"), (True, "PASS")])
def test_conditional_controls_are_not_waivers(flag, expected, docs):
    data = fixture("salesforce")
    data["capabilities"]["custom_code"] = flag
    result = app.evaluate(data, docs)
    rows = [row for row in result["findings"] if row["control_id"] == "SF-006"]
    assert rows and all(row["status"] == expected for row in rows)


@pytest.mark.parametrize("flag", ["false", "true", 0, 1, [], {}])
def test_capability_type_confusion_cannot_exclude_controls(flag, docs):
    data = fixture("salesforce")
    data["capabilities"]["custom_code"] = flag
    result = app.evaluate(data, docs)
    assert result["declaration_conformance"] == "BLOCKED"
    assert not any(row["control_id"] == "SF-006" and row["status"] == "NOT_APPLICABLE" for row in result["findings"])


def test_capability_missing_is_input_error(docs):
    data = fixture("servicenow")
    del data["capabilities"]["agents"]
    with pytest.raises(app.InputError):
        app.evaluate(data, docs)


@pytest.mark.parametrize("platform,capability", [("salesforce", "mid_server"), ("salesforce", "domain_separation"), ("servicenow", "data_cloud")])
def test_vendor_specific_capability_not_silently_accepted(platform, capability, docs):
    data = fixture(platform)
    data["capabilities"][capability] = True
    assert app.evaluate(data, docs)["declaration_conformance"] == "BLOCKED"


def test_any_capability_or_semantics():
    control = {"applies_when": ["agents", "write_actions"]}
    assert app.applicability(control, {"agents": True, "write_actions": None}) is True
    assert app.applicability(control, {"agents": False, "write_actions": None}) is None
    assert app.applicability(control, {"agents": False, "write_actions": False}) is False


@pytest.mark.parametrize("kind", ["remove_control", "weaken_setting", "remove_dependency", "remove_source", "unknown_field", "duplicate_id"])
def test_policy_tampering_detected(kind, docs, snapshot):
    changed = deepcopy(docs)
    filename = app.FILES["salesforce"]
    control = changed[filename]["controls"][0]
    if kind == "remove_control":
        changed[filename]["controls"].pop(0)
    elif kind == "weaken_setting":
        control["required_settings"]["salesforce_feature_org_matrix_complete"] = False
    elif kind == "remove_dependency":
        changed[filename]["inherits"] = []
    elif kind == "remove_source":
        changed[filename]["sources"] = []
    elif kind == "unknown_field":
        control["skip_validation"] = True
    elif kind == "duplicate_id":
        changed[filename]["controls"].append(deepcopy(control))
    try:
        errors = app.verify_documents(changed, snapshot)
    except app.InputError:
        return
    assert errors


@pytest.mark.parametrize("field", ["authorizes_release", "runtime_verified"])
def test_no_self_approved_release(field, docs):
    data = fixture("salesforce")
    data[field] = True
    with pytest.raises(app.InputError):
        app.evaluate(data, docs)


def test_claimed_evidence_remains_unverified(docs):
    data = fixture("salesforce")
    data["evidence"]["SF-006"] = {"status": "claimed", "references": ["EVIDENCE-REF-ONLY-NOT-FETCHED"]}
    result = app.evaluate(data, docs)
    assert result["implementation_assurance"] == "UNVERIFIED"
    assert result["authorizes_release"] is False


@pytest.mark.parametrize("status,refs", [("verified", ["ref"]), ("approved", ["ref"]), ("not_applicable", []), ("claimed", [])])
def test_invalid_evidence_claims_rejected(status, refs, docs):
    data = fixture("salesforce")
    data["evidence"]["SF-006"] = {"status": status, "references": refs}
    with pytest.raises(app.InputError):
        app.evaluate(data, docs)


def test_required_data_class_cannot_be_deleted(docs):
    data = fixture("salesforce")
    data["settings"]["prohibited_ai_data_classes"] = ["PII", "SI"]
    result = app.evaluate(data, docs)
    assert field_result(result, "SAAS-DAT-001", "prohibited_ai_data_classes")[0]["status"] == "FAIL"


@pytest.mark.parametrize("actual,expected", [(1, False), ("true", False), (True, True)])
def test_boolean_matching(actual, expected):
    assert app.equal_value(actual, True) is expected


def test_class_lists_are_unordered_but_unique():
    assert app.equal_value(["HSI", "PII", "SI"], ["PII", "SI", "HSI"])
    assert not app.equal_value(["PII", "PII", "SI", "HSI"], ["PII", "SI", "HSI"])


@pytest.mark.parametrize("text", [
    "a: 1\na: 2", "x: !!python/object/apply:os.system ['echo unsafe']",
    "x: &a [1]\ny: *a", "x: {<<: {a: 1}}", "true: x", "x: .nan", "- no-root-mapping",
    '{"x":1,"x":2}', "x: " + "[" * 41 + "0" + "]" * 41,
])
def test_unsafe_or_ambiguous_yaml_rejected(text):
    with pytest.raises(app.InputError):
        app.parse(text)


def test_oversized_input_rejected():
    with pytest.raises(app.InputError):
        app.parse("x: " + "a" * 1_000_000)


def test_only_explicit_yaml_booleans():
    value = app.parse("a: true\nb: false\nc: on\nd: yes")
    assert value == {"a": True, "b": False, "c": "on", "d": "yes"}


def test_unknown_assessment_key_rejected(docs):
    data = fixture("salesforce")
    data["skip_checks"] = True
    with pytest.raises(app.InputError):
        app.evaluate(data, docs)


def test_unknown_setting_rejected(docs):
    data = fixture("servicenow")
    data["settings"]["administrator_password"] = "DO-NOT-STORE-SECRETS"
    with pytest.raises(app.InputError):
        app.evaluate(data, docs)


def test_report_is_deterministic(docs):
    result = app.evaluate(fixture("salesforce"), docs)
    assert app.markdown_report(result) == app.markdown_report(result)
    assert "UNVERIFIED" in app.markdown_report(result)


def cli(*args):
    return subprocess.run([sys.executable, str(app.ROOT / "saas_enablement.py"), *map(str, args)],
                          capture_output=True, text=True, timeout=20)


def test_cli_definition_check():
    result = cli("check")
    assert result.returncode == 0, result.stderr
    assert "60 control definitions" in result.stdout


def test_cli_init_unknown_report_and_no_overwrite(tmp_path):
    path = tmp_path / "assessment.json"
    report = tmp_path / "report.md"
    assert cli("init", "salesforce", "--output", path).returncode == 0
    assert cli("init", "salesforce", "--output", path).returncode == 2
    result = cli("validate", path, "--report", report)
    assert result.returncode == 1
    assert report.exists() and "BLOCKED" in report.read_text()


def test_cli_synthetic_fixture_success_and_malformed_input(tmp_path):
    good = app.ROOT / "tests" / "fixtures" / "synthetic-servicenow.json"
    assert cli("validate", good).returncode == 0
    bad = tmp_path / "bad.yaml"
    bad.write_text("a: 1\na: 2")
    assert cli("validate", bad).returncode == 2
