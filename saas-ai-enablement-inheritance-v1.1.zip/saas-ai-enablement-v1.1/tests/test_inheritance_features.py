"""Independent checks for baseline inheritance and product/feature organization."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import saas_enablement as app


@pytest.fixture
def docs():
    return app.load_definitions()


def fixture(platform):
    return app.read(app.ROOT / 'tests' / 'fixtures' / f'synthetic-{platform}.json')


def reviewed_snapshot(docs):
    # Test structural rules independently of the separate policy-change tripwire.
    return {name: {'sha256': app.fingerprint(doc)} for name, doc in docs.items()}


@pytest.mark.parametrize('platform,total', [('salesforce', 82), ('servicenow', 84)])
def test_baseline_inherited_once_with_no_source_duplication(platform, total, docs):
    baseline = docs[app.FILES['vendor_neutral']]
    overlay = docs[app.FILES[platform]]
    base_ids = {c['id'] for c in baseline['controls']}
    vendor_ids = {c['id'] for c in overlay['controls']}
    assert not base_ids & vendor_ids
    resolved = app.selected_controls(platform, docs)
    ids = [c['id'] for c in resolved]
    assert len(ids) == len(set(ids)) == total
    assert base_ids <= set(ids)
    assert overlay['inherits'] == [{
        'id': 'ABC-SAAS-AI-ENABLEMENT-BASELINE', 'version': '1.1',
        'file': 'saas-ai-enablement-baseline.yaml',
    }]


@pytest.mark.parametrize('kind', ['missing', 'version', 'file', 'mode', 'second_parent'])
def test_overlay_cannot_change_its_inheritance(kind, docs):
    d = deepcopy(docs)
    vendor = d[app.FILES['salesforce']]
    if kind == 'missing':
        vendor['inherits'] = []
    elif kind == 'version':
        vendor['inherits'][0]['version'] = '999'
    elif kind == 'file':
        vendor['inherits'][0]['file'] = '../../weaker-baseline.yaml'
    elif kind == 'mode':
        vendor['inheritance_mode'] = 'replace'
    else:
        vendor['inherits'].append({'id': vendor['id'], 'version': '1.1', 'file': app.FILES['salesforce']})
    assert app.verify_documents(d, reviewed_snapshot(d))
    with pytest.raises(app.InputError):
        app.selected_controls('salesforce', d)


def test_baseline_cannot_depend_on_a_vendor(docs):
    d = deepcopy(docs)
    d[app.FILES['vendor_neutral']]['inherits'] = [{
        'id': 'ABC-SALESFORCE-AI-ENABLEMENT', 'version': '1.1',
        'file': 'salesforce-ai-enablement.yaml',
    }]
    assert app.verify_documents(d, reviewed_snapshot(d))


def test_duplicate_cannot_override_an_inherited_control(docs):
    d = deepcopy(docs)
    base = deepcopy(d[app.FILES['vendor_neutral']]['controls'][0])
    base['required_settings']['unreviewed_ai_features_enabled'] = True
    d[app.FILES['salesforce']]['controls'].append(base)
    with pytest.raises(app.InputError):
        app.verify_documents(d, reviewed_snapshot(d))
    with pytest.raises(app.InputError):
        app.selected_controls('salesforce', d)


def test_no_vendor_specific_flags_in_baseline(docs):
    baseline = docs[app.FILES['vendor_neutral']]
    assert not {'data_cloud', 'mid_server', 'domain_separation', 'prompt_builder'} & set(baseline['scope']['capability_flags'])
    assert all(c['id'].startswith('SAAS-') for c in baseline['controls'])


@pytest.mark.parametrize('platform', ['salesforce', 'servicenow'])
def test_disabling_optional_features_does_not_remove_baseline(platform, docs):
    data = fixture(platform)
    data['capabilities'] = {key: False for key in app.CAPABILITIES}
    data['settings']['human_mfa_required'] = False
    result = app.evaluate(data, docs)
    row = next(r for r in result['findings'] if r['field'] == 'settings.human_mfa_required')
    assert row['status'] == 'FAIL'
    assert row['origin']['layer'] == 'inherited_baseline'
    assert result['declaration_conformance'] == 'BLOCKED'


@pytest.mark.parametrize('enabled,status', [(True, 'PASS'), (False, 'NOT_APPLICABLE'), (None, 'UNKNOWN')])
def test_prompt_builder_is_feature_scoped_not_universal(enabled, status, docs):
    data = fixture('salesforce')
    data['capabilities']['prompt_builder'] = enabled
    rows = [r for r in app.evaluate(data, docs)['findings'] if r['control_id'] == 'SF-007']
    assert rows and {r['status'] for r in rows} == {status}
    assert all(r['origin']['feature_id'] == 'prompt_builder' for r in rows)


@pytest.mark.parametrize('platform,cid,flag,feature', [
    ('salesforce', 'SF-003', 'agents', 'agentforce'),
    ('salesforce', 'SF-010', 'data_cloud', 'data_cloud'),
    ('servicenow', 'SN-005', 'agents', 'ai_agents'),
    ('servicenow', 'SN-016', 'external_connectors', 'integration_hub'),
    ('servicenow', 'SN-017', 'mid_server', 'mid_server'),
])
def test_feature_controls_and_inherited_capability_rules_both_apply(platform, cid, flag, feature, docs):
    data = fixture(platform)
    data['capabilities'] = {key: False for key in app.CAPABILITIES}
    data['capabilities'][flag] = True
    effective = app.effective_requirements(data, docs)
    row = next(r for r in effective['controls'] if r['control_id'] == cid)
    assert row['applicability'] == 'APPLICABLE'
    assert row['origin']['feature_id'] == feature
    if flag == 'agents':
        base = next(r for r in effective['controls'] if r['control_id'] == 'SAAS-AI-006')
        assert base['applicability'] == 'APPLICABLE'
        assert base['origin']['layer'] == 'inherited_baseline'


@pytest.mark.parametrize('kind', ['missing', 'unknown_ref', 'duplicate_ref', 'weaken_trigger', 'move_always_control', 'unknown_property'])
def test_feature_index_cannot_omit_or_weaken_controls(kind, docs):
    d = deepcopy(docs)
    vendor = d[app.FILES['salesforce']]
    feature = vendor['features']['prompt_builder']
    if kind == 'missing':
        del vendor['features']['prompt_builder']
    elif kind == 'unknown_ref':
        feature['control_refs'] = ['SF-999']
    elif kind == 'duplicate_ref':
        vendor['features']['another_prompt_builder'] = deepcopy(feature)
    elif kind == 'weaken_trigger':
        feature['applies_when'] = ['agents']
    elif kind == 'move_always_control':
        vendor['platform_control_refs'].remove('SF-001')
    else:
        feature['skip_baseline'] = True
    with pytest.raises(app.InputError):
        app.verify_documents(d, reviewed_snapshot(d))


def test_generated_origin_retains_control_links_without_verifying_evidence(docs):
    result = app.effective_requirements(fixture('salesforce'), docs)
    origin = {r['control_id']: r['origin'] for r in result['controls']}
    assert origin['SAAS-IAM-001']['layer'] == 'inherited_baseline'
    assert origin['SF-004']['layer'] == 'vendor_platform'
    assert origin['SF-007']['feature_id'] == 'prompt_builder'
    assert result['implementation_assurance'] == 'UNVERIFIED'
    assert result['authorizes_release'] is False
    assert json.dumps(result, sort_keys=True) == json.dumps(app.effective_requirements(fixture('salesforce'), docs), sort_keys=True)


def test_new_draft_does_not_select_or_approve_prompt_builder(docs):
    data = app.new_assessment('salesforce', docs)
    assert data['capabilities']['prompt_builder'] is None
    assert all(v is None for v in data['settings'].values())


def test_cli_resolve_emits_full_set_and_does_not_overwrite(tmp_path):
    output = tmp_path / 'effective.json'
    source = app.ROOT / 'tests' / 'fixtures' / 'synthetic-servicenow.json'
    cmd = [sys.executable, str(app.ROOT / 'saas_enablement.py'), 'resolve', str(source), '--output', str(output)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    assert result.returncode == 0, result.stderr
    data = json.loads(output.read_text())
    assert len(data['controls']) == 84
    assert data['authorizes_release'] is False
    again = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    assert again.returncode == 2
