"""Small offline SaaS AI declaration checker; never a tenant or approval verifier."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parent
FILES = {
    "vendor_neutral": "saas-ai-enablement-baseline.yaml",
    "salesforce": "salesforce-ai-enablement.yaml",
    "servicenow": "service-now-ai-enablement.yaml",
}
IDS = {
    "vendor_neutral": "ABC-SAAS-AI-ENABLEMENT-BASELINE",
    "salesforce": "ABC-SALESFORCE-AI-ENABLEMENT",
    "servicenow": "ABC-SERVICENOW-AI-ENABLEMENT",
}
CAPABILITIES = (
    "retrieval", "agents", "write_actions", "external_connectors", "custom_code",
    "mcp", "external_users", "multimodal", "domain_separation", "data_cloud",
    "custom_models", "mid_server", "prompt_builder",
)
UNSUPPORTED_CAPABILITIES = {
    "salesforce": {"domain_separation", "mid_server"},
    "servicenow": {"data_cloud", "prompt_builder"},
}
GENERIC_CAPABILITIES = (
    "retrieval", "agents", "write_actions", "external_connectors", "custom_code",
    "mcp", "external_users", "multimodal", "custom_models",
)
VENDOR_CAPABILITIES = {
    "salesforce": ("data_cloud", "prompt_builder"),
    "servicenow": ("domain_separation", "mid_server"),
}
TOP_FIELDS = {
    "schema_version", "id", "version", "status", "name", "track", "platform",
    "inherits", "inheritance_mode", "scope", "interpretation", "controls", "sources",
}
CONTROL_FIELDS = {
    "id", "name", "domain", "severity", "applies_when", "responsibility",
    "requirement", "implementation", "required_settings", "evidence_required",
    "validation", "supports_baseline", "source_refs",
}
SCOPE_FIELDS = {
    "tenant_id", "feature_names", "release_or_version", "license_or_sku",
    "processing_regions", "model_routes", "owner_role", "audience",
}
ASSESSMENT_FIELDS = {
    "schema_version", "platform", "scope", "capabilities", "settings",
    "evidence", "runtime_verified", "authorizes_release",
}


class InputError(ValueError):
    """Malformed, oversized or unsupported local input."""


class StrictLoader(yaml.SafeLoader):
    """No executable tags, duplicate keys, YAML aliases, or merge keys."""


# YAML's yes/no/on/off implicit booleans are deliberately not accepted as booleans.
StrictLoader.yaml_implicit_resolvers = {
    key: [(tag, rx) for tag, rx in value
          if tag not in {"tag:yaml.org,2002:bool", "tag:yaml.org,2002:timestamp"}]
    for key, value in yaml.SafeLoader.yaml_implicit_resolvers.items()
}
StrictLoader.add_implicit_resolver(
    "tag:yaml.org,2002:bool", re.compile(r"^(?:true|false)$"), list("tf")
)


def _mapping(loader: StrictLoader, node: yaml.MappingNode, deep: bool = False) -> dict:
    result: dict[str, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if not isinstance(key, str) or key == "<<":
            raise InputError("Mapping keys must be strings; YAML merging is not supported.")
        if key in result:
            raise InputError(f"Duplicate mapping key: {key}")
        result[key] = loader.construct_object(value_node, deep=deep)
    return result


StrictLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)


def parse(text: str) -> dict:
    if len(text.encode("utf-8")) > 1_000_000:
        raise InputError("Input exceeds the 1 MB limit.")
    try:
        depth = 0
        count = 0
        for event in yaml.parse(text, Loader=StrictLoader):
            count += 1
            if isinstance(event, yaml.AliasEvent) or getattr(event, "anchor", None):
                raise InputError("YAML anchors and aliases are not supported.")
            if isinstance(event, (yaml.MappingStartEvent, yaml.SequenceStartEvent)):
                depth += 1
            if isinstance(event, (yaml.MappingEndEvent, yaml.SequenceEndEvent)):
                depth -= 1
            if depth > 40 or count > 50_000:
                raise InputError("Input exceeds nesting or node limits.")
        data = yaml.load(text, Loader=StrictLoader)
        if not isinstance(data, dict):
            raise InputError("The document root must be a mapping.")
        json.dumps(data, allow_nan=False)  # Only finite, JSON-compatible scalar values.
        return data
    except (yaml.YAMLError, TypeError, ValueError, RecursionError) as exc:
        if isinstance(exc, InputError):
            raise
        raise InputError(f"Invalid YAML/JSON: {exc}") from exc


def read(path: Path) -> dict:
    if path.stat().st_size > 1_000_000:
        raise InputError("Input exceeds the 1 MB limit.")
    return parse(path.read_text(encoding="utf-8"))


def fingerprint(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _keys(data: Any, fields: set[str], label: str) -> None:
    if not isinstance(data, dict) or set(data) != fields:
        actual = set(data) if isinstance(data, dict) else set()
        raise InputError(
            f"{label}: missing keys {sorted(fields - actual)}; "
            f"unexpected keys {sorted(actual - fields)}."
        )


def _strings(value: Any, label: str, nonempty: bool = True) -> None:
    if (not isinstance(value, list) or (nonempty and not value)
            or any(not isinstance(v, str) or not v.strip() for v in value)
            or len(set(value)) != len(value)):
        raise InputError(f"{label}: expected a list of unique nonempty strings.")


def verify_documents(docs: dict, snapshot: dict) -> list[str]:
    """Check a protected policy definition set; snapshot is a change tripwire, not a signature."""
    if set(docs) != set(FILES.values()) or set(snapshot) != set(FILES.values()):
        raise InputError("Exactly the baseline and two supported vendor overlays are required.")
    problems: list[str] = []
    seen: set[str] = set()
    baseline_ids: set[str] = set()
    all_setting_keys: set[str] = set()
    for platform, filename in FILES.items():
        doc = docs[filename]
        fields = TOP_FIELDS | ({"governance"} if platform == "vendor_neutral" else {"platform_control_refs", "features"})
        _keys(doc, fields, filename)
        if (doc["id"] != IDS[platform] or doc["schema_version"] != "saas-enablement/1.1"
                or doc["platform"] != platform or doc["track"] != "saas"
                or doc["version"] != "1.1" or doc["status"] != "draft"):
            raise InputError(f"{filename}: unsupported identity, schema, version or lifecycle.")
        expected_deps = [] if platform == "vendor_neutral" else [
            {"id": IDS["vendor_neutral"], "version": "1.1", "file": FILES["vendor_neutral"]}
        ]
        if doc["inherits"] != expected_deps or doc["inheritance_mode"] != "additive_only":
            problems.append(f"{filename}: mandatory baseline dependency was changed.")
        expected_flags = list(GENERIC_CAPABILITIES) + list(VENDOR_CAPABILITIES.get(platform, ()))
        if not isinstance(doc["scope"], dict) or doc["scope"].get("capability_flags") != expected_flags:
            raise InputError(f"{filename}: unsupported capability vocabulary.")
        _strings(doc["interpretation"], f"{filename}.interpretation")
        if not isinstance(doc["sources"], list):
            raise InputError("sources must be a list.")
        source_ids: set[str] = set()
        for source in doc["sources"]:
            _keys(source, {"id", "title", "url", "accessed_on", "use_note"}, "source")
            if source["id"] in source_ids:
                raise InputError(f"Duplicate source ID: {source['id']}")
            if not isinstance(source["url"], str) or not source["url"].startswith("https://"):
                raise InputError("Source URLs must be HTTPS references; they are not fetched.")
            source_ids.add(source["id"])
        controls = doc["controls"]
        if not isinstance(controls, list) or not controls:
            raise InputError(f"{filename}: nonempty controls are required.")
        for control in controls:
            _keys(control, CONTROL_FIELDS, f"{filename}.control")
            cid = control["id"]
            if not isinstance(cid, str) or not re.fullmatch(r"[A-Z]+(?:-[A-Z]+)*-\d{3}", cid):
                raise InputError("Control IDs must be stable uppercase identifiers.")
            prefix = {"vendor_neutral": "SAAS-", "salesforce": "SF-", "servicenow": "SN-"}[platform]
            if not cid.startswith(prefix):
                raise InputError(f"{filename}: control namespace {cid} cannot redefine inherited controls.")
            if cid in seen:
                raise InputError(f"Duplicate control ID: {cid}")
            seen.add(cid)
            for field in ("name", "domain", "requirement", "implementation"):
                if not isinstance(control[field], str) or not control[field].strip():
                    raise InputError(f"{cid}.{field} must contain text.")
            if control["severity"] not in {"critical", "high", "medium", "low"}:
                raise InputError(f"{cid}: invalid severity.")
            if control["responsibility"] not in {"customer", "vendor", "shared"}:
                raise InputError(f"{cid}: invalid responsibility.")
            when = control["applies_when"]
            _strings(when, f"{cid}.applies_when")
            if not set(when) <= set(expected_flags) | {"always"} or ("always" in when and len(when) != 1):
                raise InputError(f"{cid}: invalid applicability expression.")
            _strings(control["evidence_required"], f"{cid}.evidence_required")
            _strings(control["supports_baseline"], f"{cid}.supports_baseline", False)
            _strings(control["source_refs"], f"{cid}.source_refs", False)
            if not set(control["source_refs"]) <= source_ids:
                problems.append(f"{cid}: undefined source reference.")
            if platform == "vendor_neutral":
                baseline_ids.add(cid)
                if control["supports_baseline"]:
                    problems.append(f"{cid}: baseline cannot inherit an overlay.")
            elif not set(control["supports_baseline"]) <= baseline_ids:
                problems.append(f"{cid}: undefined baseline control reference.")
            settings = control["required_settings"]
            if not isinstance(settings, dict):
                raise InputError(f"{cid}.required_settings must be a mapping.")
            for key, value in settings.items():
                if not isinstance(key, str) or not re.fullmatch(r"[a-z][a-z0-9_]*", key):
                    raise InputError(f"{cid}: invalid setting name.")
                if key in all_setting_keys:
                    raise InputError(f"Setting has multiple owners: {key}")
                all_setting_keys.add(key)
                if type(value) not in {bool, str, list}:
                    raise InputError(f"{cid}.{key}: unsupported required value.")
                if isinstance(value, list):
                    _strings(value, f"{cid}.{key}")
            _keys(control["validation"], {"mode", "negative_scenario"}, f"{cid}.validation")
            expected_mode = "declared_settings_and_evidence" if settings else "manual_evidence"
            if control["validation"]["mode"] != expected_mode:
                problems.append(f"{cid}: check/evidence mode does not match its settings.")
            if not isinstance(control["validation"]["negative_scenario"], str) or not control["validation"]["negative_scenario"].strip():
                raise InputError(f"{cid}: a concrete negative scenario is required.")
        if platform != "vendor_neutral":
            verify_feature_index(doc)
        if fingerprint(doc) != snapshot[filename].get("sha256"):
            problems.append(f"{filename}: policy changed; independent security review and snapshot update required.")
    return problems


def verify_feature_index(doc: dict) -> None:
    """Every vendor control belongs to the platform or exactly one feature group."""
    controls = {control["id"]: control for control in doc["controls"]}
    platform_refs = doc["platform_control_refs"]
    _strings(platform_refs, "platform_control_refs")
    expected_platform = {cid for cid, c in controls.items() if c["applies_when"] == ["always"]}
    if set(platform_refs) != expected_platform:
        raise InputError("Platform control references must match the vendor's always-applicable controls.")
    features = doc["features"]
    if not isinstance(features, dict) or not features:
        raise InputError("A vendor file must declare its product/feature groups.")
    assigned = set(platform_refs)
    for fid, feature in features.items():
        if not isinstance(fid, str) or not re.fullmatch(r"[a-z][a-z0-9_]*", fid):
            raise InputError("Feature IDs must be stable lowercase identifiers.")
        _keys(feature, {"product", "name", "applies_when", "control_refs"}, f"features.{fid}")
        for key in ("product", "name"):
            if not isinstance(feature[key], str) or not feature[key].strip():
                raise InputError(f"features.{fid}.{key} must contain text.")
        _strings(feature["applies_when"], f"features.{fid}.applies_when")
        _strings(feature["control_refs"], f"features.{fid}.control_refs")
        for cid in feature["control_refs"]:
            if cid not in controls or cid in assigned:
                raise InputError(f"features.{fid}: unknown or multiply assigned control {cid}.")
            if feature["applies_when"] != controls[cid]["applies_when"]:
                raise InputError(f"features.{fid}: group cannot alter the applicability of {cid}.")
            assigned.add(cid)
    if assigned != set(controls):
        raise InputError("Every additional vendor control must appear exactly once in the product/feature index.")


def load_definitions(root: Path = ROOT) -> dict:
    docs = {name: read(root / name) for name in FILES.values()}
    snapshot = read(root / "policy-snapshot.json")
    problems = verify_documents(docs, snapshot)
    if problems:
        raise InputError("\n".join(problems))
    return docs


def selected_controls(platform: str, docs: dict) -> list[dict]:
    if platform not in {"salesforce", "servicenow"}:
        raise InputError("Supported assessments are salesforce and servicenow.")
    baseline = docs[FILES["vendor_neutral"]]
    vendor = docs[FILES[platform]]
    required = [{"id": IDS["vendor_neutral"], "version": "1.1", "file": FILES["vendor_neutral"]}]
    if (vendor["inherits"] != required or vendor["inheritance_mode"] != "additive_only"
            or baseline["id"] != required[0]["id"] or baseline["version"] != required[0]["version"]):
        raise InputError("Mandatory version-pinned baseline inheritance is missing or incompatible.")
    merged = baseline["controls"] + vendor["controls"]
    ids = [control["id"] for control in merged]
    if len(set(ids)) != len(ids):
        raise InputError("Duplicate control IDs cannot override an inherited requirement.")
    return merged


def new_assessment(platform: str, docs: dict) -> dict:
    controls = selected_controls(platform, docs)
    return {
        "schema_version": "saas-assessment/1.1",
        "platform": platform,
        "scope": {key: None for key in sorted(SCOPE_FIELDS)},
        "capabilities": {key: False if key in UNSUPPORTED_CAPABILITIES[platform] else None
                         for key in CAPABILITIES},
        "settings": {key: None for c in controls for key in c["required_settings"]},
        "evidence": {c["id"]: {"status": "pending", "references": []} for c in controls},
        "runtime_verified": False,
        "authorizes_release": False,
    }


def applicability(control: dict, capabilities: dict) -> bool | None:
    when = control["applies_when"]
    if when == ["always"]:
        return True
    values = [capabilities.get(key) for key in when]
    if any(value is True for value in values):
        return True
    return False if all(value is False for value in values) else None


def equal_value(actual: Any, required: Any) -> bool:
    if type(actual) is not type(required):
        return False
    if isinstance(required, list):
        # Class lists are unordered sets, but duplicates and wrong types are invalid.
        return (all(isinstance(v, str) for v in actual)
                and len(actual) == len(set(actual)) and set(actual) == set(required))
    return actual == required


def evaluate(assessment: dict, docs: dict) -> dict:
    _keys(assessment, ASSESSMENT_FIELDS, "assessment")
    if assessment["schema_version"] != "saas-assessment/1.1":
        raise InputError("Unsupported assessment schema version.")
    if assessment["runtime_verified"] is not False or assessment["authorizes_release"] is not False:
        raise InputError("Local declarations cannot claim runtime verification or release authorization.")
    controls = selected_controls(assessment["platform"], docs)
    _keys(assessment["scope"], SCOPE_FIELDS, "scope")
    _keys(assessment["capabilities"], set(CAPABILITIES), "capabilities")
    settings = assessment["settings"]
    known_settings = {key for c in controls for key in c["required_settings"]}
    if not isinstance(settings, dict) or not set(settings) <= known_settings:
        raise InputError("Unexpected setting key or nonmapping settings.")
    evidence = assessment["evidence"]
    control_ids = {c["id"] for c in controls}
    if not isinstance(evidence, dict) or not set(evidence) <= control_ids:
        raise InputError("Unexpected evidence control reference.")
    for cid, item in evidence.items():
        _keys(item, {"status", "references"}, f"evidence.{cid}")
        _strings(item["references"], f"evidence.{cid}.references", False)
        if item["status"] not in {"pending", "claimed"}:
            raise InputError("Evidence may be pending or claimed, never self-verified.")
        if item["status"] == "claimed" and not item["references"]:
            raise InputError("A claimed evidence record must have at least one reference.")

    origins = control_origins(assessment["platform"], docs)
    findings: list[dict] = []
    def add(cid: str, status: str, field: str, required: Any, declared: Any, message: str) -> None:
        findings.append({"control_id": cid, "status": status, "field": field,
                         "required": required, "declared": declared, "remediation": message,
                         "origin": origins.get(cid, {"layer": "assessment_scope"})})

    for field, value in assessment["scope"].items():
        if value is None or value == "" or value == []:
            add("SCOPE", "UNKNOWN", f"scope.{field}", "feature-scoped value", value,
                "Identify the actual tenant, feature and processing scope; do not assume a whole product is approved.")
        elif not ((isinstance(value, str) and value.strip()) or
                  (isinstance(value, list) and value and all(isinstance(v, str) and v.strip() for v in value))):
            add("SCOPE", "FAIL", f"scope.{field}", "text or nonempty string list", value,
                "Use an explicit, human-readable scope value.")
    for key, value in assessment["capabilities"].items():
        if value is None:
            add("SCOPE", "UNKNOWN", f"capabilities.{key}", "explicit true or false", value,
                "Confirm whether this capability is in scope; omission is not non-applicability.")
        elif value is True and key in UNSUPPORTED_CAPABILITIES[assessment["platform"]]:
            add("SCOPE", "FAIL", f"capabilities.{key}", False, value,
                "This vendor-specific capability is not supported by the selected overlay.")
        elif type(value) is not bool:
            add("SCOPE", "FAIL", f"capabilities.{key}", "Boolean", value,
                "Use true or false, not a string or integer.")

    evidence_gaps: list[dict] = []
    for control in controls:
        cid = control["id"]
        active = applicability(control, assessment["capabilities"])
        if active is False:
            add(cid, "NOT_APPLICABLE", "applies_when", control["applies_when"], False,
                "Conditional scope only; these controls are reconsidered when a capability is enabled.")
            continue
        if active is None:
            add(cid, "UNKNOWN", "applies_when", control["applies_when"], None,
                "Resolve capability scope before excluding or assessing this control.")
            continue
        if not control["required_settings"]:
            add(cid, "PENDING", "evidence", "independent evidence review", None,
                "This control is not automatable by comparing configuration declarations.")
        for key, required in control["required_settings"].items():
            actual = settings.get(key)
            status = "UNKNOWN" if actual is None else ("PASS" if equal_value(actual, required) else "FAIL")
            add(cid, status, f"settings.{key}", required, actual, control["implementation"])
        entry = evidence.get(cid, {"status": "pending", "references": []})
        evidence_gaps.append({"control_id": cid, "status": entry["status"],
                              "references": entry["references"], "required": control["evidence_required"]})
    counts = {status: sum(row["status"] == status for row in findings)
              for status in ("PASS", "FAIL", "UNKNOWN", "PENDING", "NOT_APPLICABLE")}
    return {
        "platform": assessment["platform"],
        "inherits": docs[FILES[assessment["platform"]]]["inherits"],
        "declaration_conformance": "PASS" if not counts["FAIL"] and not counts["UNKNOWN"] else "BLOCKED",
        "implementation_assurance": "UNVERIFIED", "authorizes_release": False,
        "counts": counts, "findings": findings, "evidence_review": evidence_gaps,
        "limitation": "Checks cover logical declarations only; evidence references are not fetched, verified, or approved.",
    }


def control_origins(platform: str, docs: dict) -> dict:
    baseline = docs[FILES["vendor_neutral"]]
    vendor = docs[FILES[platform]]
    origins = {
        c["id"]: {"layer": "inherited_baseline", "file": FILES["vendor_neutral"],
                  "policy_id": baseline["id"], "version": baseline["version"]}
        for c in baseline["controls"]
    }
    for cid in vendor["platform_control_refs"]:
        origins[cid] = {"layer": "vendor_platform", "file": FILES[platform],
                        "policy_id": vendor["id"], "version": vendor["version"]}
    for fid, feature in vendor["features"].items():
        for cid in feature["control_refs"]:
            origins[cid] = {"layer": "vendor_feature", "file": FILES[platform],
                            "policy_id": vendor["id"], "version": vendor["version"],
                            "feature_id": fid, "product": feature["product"]}
    return origins


def effective_requirements(assessment: dict, docs: dict) -> dict:
    """Materialize inherited requirements for review, never as a replacement policy."""
    result = evaluate(assessment, docs)
    platform = assessment["platform"]
    origins = control_origins(platform, docs)
    records = []
    for c in selected_controls(platform, docs):
        active = applicability(c, assessment["capabilities"])
        records.append({"control_id": c["id"], "name": c["name"], "origin": origins[c["id"]],
                        "applicability": {True: "APPLICABLE", False: "NOT_APPLICABLE", None: "UNKNOWN"}[active],
                        "applies_when": c["applies_when"], "requirement": c["requirement"],
                        "required_settings": c["required_settings"], "evidence_required": c["evidence_required"]})
    return {"platform": platform, "inherits": result["inherits"], "inheritance_mode": "additive_only",
            "declaration_conformance": result["declaration_conformance"], "controls": records,
            "implementation_assurance": "UNVERIFIED", "authorizes_release": False,
            "limitation": "Generated requirements only. Baseline controls are never copied into a vendor source file; "
                          "applicability comes from declarations, not observed tenant features."}


def markdown_report(result: dict) -> str:
    def cell(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False).replace("|", "\\|").replace("<", "&lt;").replace(">", "&gt;")
    lines = [f"# {result['platform']} AI enablement declaration review", "",
             f"**Declaration conformance:** {result['declaration_conformance']}",
             "**Implementation assurance: UNVERIFIED. Release authorization: false.**", "",
             result["limitation"], "", "## Inheritance", "",
             "Effective controls = applicable shared baseline + vendor platform controls + applicable feature controls.",
             "Baseline reference: " + cell(result["inherits"]), "", "## Declaration results", "",
             "| Control | Origin | Field | Required | Declared | Result | Remediation |",
             "|---|---|---|---|---|---|---|"]
    for row in result["findings"]:
        lines.append("| " + " | ".join(cell(row[key]) for key in
                     ("control_id", "origin", "field", "required", "declared", "status", "remediation")) + " |")
    lines += ["", "## Evidence review remains outstanding", "",
              "Pending and claimed references both require independent review. No evidence content is embedded.", "",
              "| Control | Submitted state | Required evidence |", "|---|---|---|"]
    for row in result["evidence_review"]:
        lines.append(f"| {row['control_id']} | {row['status']} | {cell(row['required'])} |")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("check", help="Check all three security definition files against the policy snapshot.")
    init = sub.add_parser("init", help="Create an incomplete assessment; does not copy passing settings.")
    init.add_argument("platform", choices=("salesforce", "servicenow"))
    init.add_argument("--output", type=Path, required=True)
    val = sub.add_parser("validate", help="Check declared tenant settings, never live tenant configuration.")
    val.add_argument("assessment", type=Path)
    val.add_argument("--report", type=Path)
    resolve = sub.add_parser("resolve", help="Show the effective inherited control set for an assessment.")
    resolve.add_argument("assessment", type=Path)
    resolve.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        docs = load_definitions()
        if args.command == "check":
            for filename, doc in docs.items():
                print(f"PASS {filename}: {len(doc['controls'])} control definitions")
            print("Definition integrity only; no tenant security or release approval is asserted.")
            return 0
        if args.command == "init":
            if args.output.exists():
                raise InputError("Output already exists; existing assessments are never overwritten.")
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("x", encoding="utf-8") as stream:
                json.dump(new_assessment(args.platform, docs), stream, indent=2)
                stream.write("\n")
            print(f"Created {args.output}. Scope/settings are unknown; evidence is pending.")
            return 0
        if args.command == "resolve":
            result = effective_requirements(read(args.assessment), docs)
            args.output.parent.mkdir(parents=True, exist_ok=True)
            # Avoid overwriting an input or an existing result accidentally.
            with args.output.open("x", encoding="utf-8") as stream:
                json.dump(result, stream, indent=2)
                stream.write("\n")
            print(f"Resolved {len(result['controls'])} inherited/additional requirements to {args.output}.")
            print(f"Declarations: {result['declaration_conformance']}; runtime security UNVERIFIED.")
            return 0 if result["declaration_conformance"] == "PASS" else 1
        result = evaluate(read(args.assessment), docs)
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(markdown_report(result), encoding="utf-8")
        print(f"Declaration conformance: {result['declaration_conformance']}")
        print(json.dumps(result["counts"], sort_keys=True))
        print("Implementation assurance: UNVERIFIED; authorizes_release: false")
        return 0 if result["declaration_conformance"] == "PASS" else 1
    except (InputError, OSError, UnicodeError, KeyError, TypeError) as exc:
        print(f"Input/definition error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
