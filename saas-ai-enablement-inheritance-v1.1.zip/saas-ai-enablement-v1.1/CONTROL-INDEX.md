# Control index — inherited baseline and vendor additions

106 distinct draft controls. Definitions are not verified implementation or authorization.

The vendor files inherit the version-pinned baseline; they contain no copied baseline control definitions.

## SaaS AI enablement security baseline

Source: `saas-ai-enablement-baseline.yaml`; version `1.1`.

| ID | Control | Domain | Applicability | Check mode |
|---|---|---|---|---|
| SAAS-GOV-001 | Feature-specific authorization boundary | Governance | always | declared_settings_and_evidence |
| SAAS-GOV-002 | End-to-end security ownership and endorsement | Governance | always | manual_evidence |
| SAAS-GOV-003 | Reuse existing assurance without hidden gaps | Governance | always | manual_evidence |
| SAAS-GOV-004 | Controlled rollout and separation of environments | Governance | always | declared_settings_and_evidence |
| SAAS-GOV-005 | Version-bound decisions and exceptions | Governance | always | manual_evidence |
| SAAS-GOV-006 | Human accountability and acceptable use | Governance | always | declared_settings_and_evidence |
| SAAS-IAM-001 | Enterprise sign-in and MFA | Identity and access | always | declared_settings_and_evidence |
| SAAS-IAM-002 | AI entitlements and least privilege | Identity and access | always | declared_settings_and_evidence |
| SAAS-IAM-003 | Joiner/mover/leaver and access recertification | Identity and access | always | declared_settings_and_evidence |
| SAAS-IAM-004 | Privileged administration and separation of duties | Identity and access | always | declared_settings_and_evidence |
| SAAS-IAM-005 | Sessions, devices and untrusted channels | Identity and access | always | declared_settings_and_evidence |
| SAAS-IAM-006 | Nonhuman identities and delegation | Identity and access | agents OR external_connectors OR write_actions | declared_settings_and_evidence |
| SAAS-DAT-001 | Data classification and allowed scope | Data protection | always | declared_settings_and_evidence |
| SAAS-DAT-002 | Data minimization and field selection | Data protection | always | declared_settings_and_evidence |
| SAAS-DAT-003 | Record, field and source permission preservation | Data protection | always | declared_settings_and_evidence |
| SAAS-DAT-004 | Sensitive-content prevention before processing | Data protection | always | declared_settings_and_evidence |
| SAAS-DAT-005 | Encryption across the complete AI data path | Cryptography and secrets | always | declared_settings_and_evidence |
| SAAS-DAT-006 | Key management and cryptographic coverage | Cryptography and secrets | always | manual_evidence |
| SAAS-DAT-007 | No training or secondary reuse | Data lifecycle and privacy | always | declared_settings_and_evidence |
| SAAS-DAT-008 | Separate model-provider retention from SaaS storage | Data lifecycle and privacy | always | declared_settings_and_evidence |
| SAAS-DAT-009 | Purpose-bound content and audit retention | Data lifecycle and privacy | always | declared_settings_and_evidence |
| SAAS-DAT-010 | Processing location and cross-border routes | Data lifecycle and privacy | always | declared_settings_and_evidence |
| SAAS-DAT-011 | Deletion, revocation and derived-data lifecycle | Data lifecycle and privacy | always | declared_settings_and_evidence |
| SAAS-DAT-012 | Tenant, user and session isolation | Data protection | always | declared_settings_and_evidence |
| SAAS-DAT-013 | Vendor support and human access | Third-party assurance | always | manual_evidence |
| SAAS-NET-001 | SaaS network and access boundary | Network and integration security | always | declared_settings_and_evidence |
| SAAS-NET-002 | External destinations and exfiltration prevention | Network and integration security | external_connectors OR agents OR write_actions | declared_settings_and_evidence |
| SAAS-NET-003 | Credentials, tokens and secret references | Cryptography and secrets | always | declared_settings_and_evidence |
| SAAS-NET-004 | API, webhook and tool input validation | Network and integration security | external_connectors OR write_actions OR custom_code | declared_settings_and_evidence |
| SAAS-AI-001 | Feature-level AI protection coverage | AI security | always | declared_settings_and_evidence |
| SAAS-AI-002 | Direct and indirect prompt-injection resistance | AI security | always | declared_settings_and_evidence |
| SAAS-AI-003 | Safe output handling and downstream consumption | AI security | always | declared_settings_and_evidence |
| SAAS-AI-004 | Grounding integrity and human verification | AI security | always | declared_settings_and_evidence |
| SAAS-AI-005 | Prompt and configuration secrecy boundaries | AI security | always | declared_settings_and_evidence |
| SAAS-AI-006 | Agent tool minimization and explicit authority | Agent and action security | agents | declared_settings_and_evidence |
| SAAS-AI-007 | Per-action authorization and secure writeback | Agent and action security | write_actions | declared_settings_and_evidence |
| SAAS-AI-008 | Human confirmation for business effects | Agent and action security | write_actions | declared_settings_and_evidence |
| SAAS-AI-009 | Bounded execution and recovery | Agent and action security | agents | declared_settings_and_evidence |
| SAAS-AI-010 | Conversation memory and learning governance | Agent and action security | agents | declared_settings_and_evidence |
| SAAS-AI-011 | Safe failure of required safeguards | AI security | always | declared_settings_and_evidence |
| SAAS-RAG-001 | Approved retrieval sources and ingestion | Retrieval and knowledge security | retrieval | declared_settings_and_evidence |
| SAAS-RAG-002 | Permission-aware retrieval and citations | Retrieval and knowledge security | retrieval | declared_settings_and_evidence |
| SAAS-RAG-003 | Index change and access-revocation propagation | Retrieval and knowledge security | retrieval | declared_settings_and_evidence |
| SAAS-INT-001 | Connector authorization and consent | Network and integration security | external_connectors | declared_settings_and_evidence |
| SAAS-INT-002 | Custom code and packaged extension security | Application and supply-chain security | custom_code | declared_settings_and_evidence |
| SAAS-INT-003 | MCP and agent-to-agent trust boundary | Agent and action security | mcp | declared_settings_and_evidence |
| SAAS-MON-001 | Security events and action traceability | Monitoring and detection | always | declared_settings_and_evidence |
| SAAS-MON-002 | Central detection and incident correlation | Monitoring and detection | always | declared_settings_and_evidence |
| SAAS-MON-003 | Protected logs and redacted diagnostics | Monitoring and detection | always | declared_settings_and_evidence |
| SAAS-MON-004 | Security testing and evidence freshness | Security assurance | always | manual_evidence |
| SAAS-OPS-001 | Vendor security and infrastructure assurance | Third-party assurance | always | manual_evidence |
| SAAS-OPS-002 | AI incident response and breach handling | Operations and resilience | always | manual_evidence |
| SAAS-OPS-003 | Emergency disablement and credential revocation | Operations and resilience | always | declared_settings_and_evidence |
| SAAS-OPS-004 | Business continuity and safe non-AI fallback | Operations and resilience | always | manual_evidence |
| SAAS-OPS-005 | Consumption and resource-abuse controls | Operations and resilience | always | declared_settings_and_evidence |
| SAAS-OPS-006 | Material-change control and recertification | Operations and resilience | always | declared_settings_and_evidence |
| SAAS-OPS-007 | Exit, portability and complete decommissioning | Operations and resilience | always | manual_evidence |
| SAAS-PRV-001 | Privacy, legal and model-risk applicability | Privacy and business risk | always | manual_evidence |
| SAAS-CHN-001 | External audience and public-channel protections | Channel security | external_users | declared_settings_and_evidence |
| SAAS-CHN-002 | Attachments, voice and screen inputs | Channel security | multimodal | declared_settings_and_evidence |

## Salesforce AI enablement security overlay

Source: `salesforce-ai-enablement.yaml`; version `1.1`.

Inherits: `ABC-SAAS-AI-ENABLEMENT-BASELINE@1.1` with `additive_only` composition.

### Product/feature groups

| Group | Product/review area | Activated by (OR) | Additional controls |
|---|---|---|---|
| agentforce | Agentforce | agents | SF-003, SF-022 |
| flow_actions | Salesforce Flow and actions | write_actions OR custom_code | SF-005 |
| apex_actions | Apex | custom_code | SF-006 |
| prompt_builder | Prompt Builder | prompt_builder | SF-007 |
| data_cloud | Data Cloud / Data 360 | data_cloud | SF-010 |
| retrieval_knowledge | Salesforce retrieval and Knowledge | retrieval | SF-011, SF-012 |
| external_connections | Salesforce credentials and integrations | external_connectors | SF-013 |
| external_channels | Salesforce external AI channels | external_users | SF-014 |
| write_actions | Salesforce AI actions | write_actions | SF-015 |
| custom_model_routes | Salesforce custom models and APIs | custom_models OR custom_code | SF-017 |
| packages_mcp | Salesforce AI extensions | mcp OR custom_code | SF-021 |

### All vendor-specific control definitions

| ID | Control | Domain | Applicability | Check mode |
|---|---|---|---|---|
| SF-001 | Salesforce feature and org inventory | Governance | always | declared_settings_and_evidence |
| SF-002 | AI permission sets and builder separation | Identity and access | always | declared_settings_and_evidence |
| SF-003 | Agent identity and effective execution authority | Identity and access | agents | declared_settings_and_evidence |
| SF-004 | Object, field and record authorization | Data protection | always | declared_settings_and_evidence |
| SF-005 | Flow and action execution context | Application and supply-chain security | write_actions OR custom_code | declared_settings_and_evidence |
| SF-006 | Secure Apex behind AI actions | Application and supply-chain security | custom_code | declared_settings_and_evidence |
| SF-007 | Prompt Builder and grounding boundaries | AI security | prompt_builder | declared_settings_and_evidence |
| SF-008 | Trust Layer coverage by feature and route | AI security | always | declared_settings_and_evidence |
| SF-009 | Third-party retention versus Salesforce-held data | Data lifecycle and privacy | always | declared_settings_and_evidence |
| SF-010 | Data Cloud/Data 360 access and segregation | Retrieval and knowledge security | data_cloud | declared_settings_and_evidence |
| SF-011 | Retrievers, indexes and connected sources | Retrieval and knowledge security | retrieval | declared_settings_and_evidence |
| SF-012 | Knowledge visibility and file access | Retrieval and knowledge security | retrieval | declared_settings_and_evidence |
| SF-013 | External and named credential scope | Network and integration security | external_connectors | declared_settings_and_evidence |
| SF-014 | Guest and customer-facing agent channels | Channel security | external_users | declared_settings_and_evidence |
| SF-015 | Action confirmation and outbound communication | Agent and action security | write_actions | declared_settings_and_evidence |
| SF-016 | AI audit, session tracing and log exports | Monitoring and detection | always | declared_settings_and_evidence |
| SF-017 | Custom model and direct API routes | AI security | custom_models OR custom_code | declared_settings_and_evidence |
| SF-018 | Salesforce configuration promotion and regression | Security assurance | always | declared_settings_and_evidence |
| SF-019 | Disable all agent and feature entry points | Operations and resilience | always | declared_settings_and_evidence |
| SF-020 | Salesforce encryption coverage limits | Cryptography and secrets | always | manual_evidence |
| SF-021 | Third-party agents, packages and MCP extensions | Application and supply-chain security | mcp OR custom_code | declared_settings_and_evidence |
| SF-022 | Agent memory, history and feedback separation | Agent and action security | agents | declared_settings_and_evidence |

## ServiceNow AI enablement security overlay

Source: `service-now-ai-enablement.yaml`; version `1.1`.

Inherits: `ABC-SAAS-AI-ENABLEMENT-BASELINE@1.1` with `additive_only` composition.

### Product/feature groups

| Group | Product/review area | Activated by (OR) | Additional controls |
|---|---|---|---|
| ai_agents | ServiceNow AI agents | agents | SN-005, SN-006, SN-007, SN-021 |
| workflow_actions | ServiceNow workflows and AI tools | write_actions | SN-008, SN-019 |
| search_knowledge | AI Search / Knowledge | retrieval | SN-014 |
| domain_separation | ServiceNow domain separation | domain_separation | SN-015 |
| integration_hub | IntegrationHub | external_connectors | SN-016 |
| mid_server | MID Server | mid_server | SN-017 |
| custom_skills_code | Now Assist skills / custom scripts | custom_code | SN-018 |
| external_channels | Virtual Agent / external channels | external_users | SN-020 |

### All vendor-specific control definitions

| ID | Control | Domain | Applicability | Check mode |
|---|---|---|---|---|
| SN-001 | Instance, release, plugin and skill inventory | Governance | always | declared_settings_and_evidence |
| SN-002 | Administration, steward and privacy roles | Identity and access | always | declared_settings_and_evidence |
| SN-003 | Table, record, field and attachment authorization | Data protection | always | declared_settings_and_evidence |
| SN-004 | Skill invocation ACLs | Identity and access | always | declared_settings_and_evidence |
| SN-005 | Agent and workflow invocation versus execution | Identity and access | agents | declared_settings_and_evidence |
| SN-006 | Dynamic-user role masking and AI-user privileges | Identity and access | agents | declared_settings_and_evidence |
| SN-007 | Delegation and cross-agent escalation | Agent and action security | agents | declared_settings_and_evidence |
| SN-008 | Supervised business-impacting tools | Agent and action security | write_actions | declared_settings_and_evidence |
| SN-009 | Generative AI Controller and model routes | AI security | always | declared_settings_and_evidence |
| SN-010 | Effective opt-out of data sharing | Data lifecycle and privacy | always | declared_settings_and_evidence |
| SN-011 | Overflow and inference residency | Data lifecycle and privacy | always | declared_settings_and_evidence |
| SN-012 | Data Privacy policy and channel coverage | Data protection | always | declared_settings_and_evidence |
| SN-013 | Guardian enforcement and feature coverage | AI security | always | declared_settings_and_evidence |
| SN-014 | AI Search and Knowledge source permissions | Retrieval and knowledge security | retrieval | declared_settings_and_evidence |
| SN-015 | Domain separation and multi-instance boundaries | Data protection | domain_separation | declared_settings_and_evidence |
| SN-016 | IntegrationHub and outbound connections | Network and integration security | external_connectors | declared_settings_and_evidence |
| SN-017 | MID Server hybrid bridge protections | Network and integration security | mid_server | declared_settings_and_evidence |
| SN-018 | Custom skills, scripts and generated code | Application and supply-chain security | custom_code | declared_settings_and_evidence |
| SN-019 | Record writes and operational remediation | Agent and action security | write_actions | declared_settings_and_evidence |
| SN-020 | Virtual Agent and external channel identity | Channel security | external_users | declared_settings_and_evidence |
| SN-021 | Agent memory, learning and feedback | Agent and action security | agents | declared_settings_and_evidence |
| SN-022 | Guardian, skill and agent audit evidence | Monitoring and detection | always | declared_settings_and_evidence |
| SN-023 | Skill, agent, trigger and tool emergency stop | Operations and resilience | always | declared_settings_and_evidence |
| SN-024 | Clone, upgrade and configuration revalidation | Operations and resilience | always | declared_settings_and_evidence |
