# v1.1 — Explicit baseline inheritance and product/feature groups

- Replaced `depends_on` with version-pinned `inherits` and enforced `inheritance_mode: additive_only`.
- Preserved 60 shared, 22 Salesforce, and 24 ServiceNow controls without copying baseline controls into vendor files.
- Added vendor platform indexes and 11 Salesforce / 8 ServiceNow product-feature groups.
- Kept vendor-specific capability vocabulary out of the shared baseline.
- Corrected SF-007 to apply only when Prompt Builder is in scope. Unknown scope remains blocking.
- Added effective-control resolution and origin information in findings/reports.
- Added 29 regression tests; retained the existing 130 tests.
- Deliberately revised the policy snapshot for this draft structural/applicability change.
- No live tenant calls, approvals, deployment, or blanket product authorization.

## Migration
Create a new 1.1 assessment and transfer reviewed declarations/evidence explicitly. Resolve Salesforce's new `prompt_builder` flag. Do not simply change the schema label on an old assessment or populate safe values from requirements.
