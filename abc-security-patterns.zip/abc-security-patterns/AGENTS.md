# Instructions for this repository

Purpose: maintain small, readable ABC security-control and pattern definitions with executable declaration tests. No diagrams, UI, image import, cloud calls or deployment.

Facts live in `controls.yaml`, the eight `patterns/abc-*.yaml` files, and explicit workload declarations. `policy.py` is the separately reviewed security floor. Never weaken it, drop negative tests or infer missing workload settings just to obtain a pass.

Run from the repository root:

```bash
python -m pip install -r requirements.txt
python validate.py --all
python -m pytest -q
python check.py
```

Keep all names ABC. Preserve strict types, unknown-field rejection, duplicate-key rejection and independent deep-copied test fixtures. Add positive/negative cases and missing-setting cases for new automated requirements. Keep manual evidence pending, not automatically passed.

No real credentials, internal endpoint names, invented evidence or approval assertions. Passing checks apply only to declarations. Security policy/validator/test changes require trusted human review. Do not commit, push, publish or provision resources without an explicit request.
