# Demonstrated negative scenarios

These results were calculated from separate in-memory copies; the shipped good YAML was not modified.

## Response guardrails disabled

`FAIL AI-001 settings.response_guardrails` — Declared setting does not meet the proposed requirement.

## Response guardrail setting omitted

`UNKNOWN AI-001 settings.response_guardrails` — Required setting is missing or null; this is not a pass.

## Mandatory control removed from the inference pattern

`FAIL CONTROL-MISSING ABC-INFERENCE AI-001` — Mandatory pattern control was removed.

All results concern declared architecture only. No runtime deployment or security approval was performed.
