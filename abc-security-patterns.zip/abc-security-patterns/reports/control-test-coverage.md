# Executed control-test coverage

**543 test cases passed in the packaged JUnit run.** No failed, errored or skipped cases.

Counts below are executed pattern-setting scenarios, not a compliance score or runtime coverage measure.

| Control | Verification | Positive setting tests | Rejected-setting tests | Missing-setting tests |
|---|---|---:|---:|---:|
| IAM-001 | Declared settings | 2 | 2 | 2 |
| IAM-002 | Declared settings | 2 | 2 | 2 |
| DATA-001 | Declared settings | 2 | 2 | 2 |
| DATA-002 | Declared settings | 2 | 2 | 2 |
| SEC-001 | Declared settings | 1 | 1 | 1 |
| LOG-001 | Declared settings | 2 | 2 | 2 |
| LOG-002 | Declared settings | 2 | 2 | 2 |
| RES-001 | Declared settings | 1 | 1 | 1 |
| GOV-001 | Human evidence required | Pending-state checked | Definition-removal rejected | Not an automated evidence check |
| GOV-002 | Human evidence required | Pending-state checked | Definition-removal rejected | Not an automated evidence check |
| PLAT-001 | Declared settings | 2 | 2 | 2 |
| IAM-003 | Declared settings | 2 | 2 | 2 |
| NET-001 | Declared settings | 1 | 1 | 1 |
| NET-002 | Declared settings | 2 | 2 | 2 |
| SEC-002 | Declared settings | 1 | 1 | 1 |
| K8S-001 | Declared settings | 2 | 2 | 2 |
| K8S-002 | Declared settings | 2 | 2 | 2 |
| SUP-001 | Declared settings | 3 | 3 | 3 |
| OPS-001 | Human evidence required | Pending-state checked | Definition-removal rejected | Not an automated evidence check |
| RES-002 | Human evidence required | Pending-state checked | Definition-removal rejected | Not an automated evidence check |
| AI-001 | Declared settings | 4 | 4 | 4 |
| AI-002 | Declared settings | 2 | 2 | 2 |
| AI-003 | Declared settings | 3 | 3 | 3 |
| AI-004 | Declared settings | 2 | 2 | 2 |
| AI-005 | Human evidence required | Pending-state checked | Definition-removal rejected | Not an automated evidence check |
| RAG-001 | Declared settings | 2 | 2 | 2 |
| RAG-002 | Declared settings | 2 | 2 | 2 |
| RAG-003 | Declared settings | 2 | 2 | 2 |
| RAG-004 | Declared settings | 2 | 2 | 2 |
| AGT-001 | Declared settings | 2 | 2 | 2 |
| AGT-002 | Declared settings | 2 | 2 | 2 |
| AGT-003 | Declared settings | 2 | 2 | 2 |
| AGT-004 | Declared settings | 2 | 2 | 2 |
| AGT-005 | Human evidence required | Pending-state checked | Definition-removal rejected | Not an automated evidence check |
| MCP-001 | Declared settings | 2 | 2 | 2 |
| MCP-002 | Declared settings | 2 | 2 | 2 |
| MCP-003 | Declared settings | 2 | 2 | 2 |
| MCP-004 | Declared settings | 2 | 2 | 2 |
| MCP-005 | Declared settings | 3 | 3 | 3 |
| MOD-001 | Declared settings | 3 | 3 | 3 |
| MOD-002 | Declared settings | 3 | 3 | 3 |
| MOD-003 | Declared settings | 2 | 2 | 2 |
| MOD-004 | Human evidence required | Pending-state checked | Definition-removal rejected | Not an automated evidence check |
| SAAS-001 | Declared settings | 2 | 2 | 2 |
| SAAS-002 | Declared settings | 2 | 2 | 2 |
| SAAS-003 | Declared settings | 2 | 2 | 2 |
| SAAS-004 | Declared settings | 2 | 2 | 2 |
| SAAS-005 | Human evidence required | Pending-state checked | Definition-removal rejected | Not an automated evidence check |
| SAAS-006 | Human evidence required | Pending-state checked | Definition-removal rejected | Not an automated evidence check |

Every automated control remains subject to independent implementation evidence. The tests do not authenticate evidence or execute live attacks against services.

The suite also includes explicit security regression cases independent of candidate YAML; workload scenarios; safe-loader checks; reference and conflict checks; CLI exit-code tests; and report checks.

Source: `reports/junit.xml`; see `reports/test-run.txt` for the captured command output.
