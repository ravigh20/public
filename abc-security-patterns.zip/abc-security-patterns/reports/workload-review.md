# ABC workload review

**Design conformance: PASS**

**Implementation assurance: UNVERIFIED. Authorizes release: false.**

Checks assess declarations, not deployed settings or runtime behavior. PENDING rows require human evidence review.

| Pattern/workload | Control/rule | Field | Required | Declared | Result | Evidence |
|---|---|---|---|---|---|---|
| ABC-DEMO-INFERENCE | LOG-001 | settings.audit_export_enabled | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | IAM-001 | settings.authorization_enforced | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | DATA-002 | settings.classification_enforced | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | NET-002 | settings.controlled_egress | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | K8S-002 | settings.default_deny_network_policy | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | AI-003 | settings.direct_model_access | false | false | PASS | pending |
| ABC-DEMO-INFERENCE | NET-002 | settings.egress_policy_ref | abc-egress-allowlist | abc-egress-allowlist | PASS | pending |
| ABC-DEMO-INFERENCE | DATA-001 | settings.encryption_at_rest | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | DATA-001 | settings.encryption_in_transit | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | IAM-001 | settings.enterprise_authentication | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | AI-002 | settings.guardrails_fail_closed | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | SUP-001 | settings.image_digest_pinning | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | SUP-001 | settings.image_registry_ref | abc-approved-registry | abc-approved-registry | PASS | pending |
| ABC-DEMO-INFERENCE | SUP-001 | settings.image_verification_required | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | SEC-001 | settings.inline_secrets | false | false | PASS | pending |
| ABC-DEMO-INFERENCE | RES-001 | settings.kill_switch_available | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | IAM-002 | settings.least_privilege | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | AI-003 | settings.model_route | abc-managed-model-route | abc-managed-model-route | PASS | pending |
| ABC-DEMO-INFERENCE | K8S-002 | settings.namespace_rbac | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | IAM-002 | settings.privileged_access_time_bound | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | K8S-001 | settings.privileged_containers | false | false | PASS | pending |
| ABC-DEMO-INFERENCE | DATA-002 | settings.prohibited_data_classes | ["PII", "SI", "HSI"] | ["PII", "SI", "HSI"] | PASS | pending |
| ABC-DEMO-INFERENCE | AI-004 | settings.provider_training_on_customer_data | false | false | PASS | pending |
| ABC-DEMO-INFERENCE | AI-003 | settings.public_model_endpoint | false | false | PASS | pending |
| ABC-DEMO-INFERENCE | NET-001 | settings.public_workload_endpoint | false | false | PASS | pending |
| ABC-DEMO-INFERENCE | LOG-002 | settings.raw_prompt_logging | false | false | PASS | pending |
| ABC-DEMO-INFERENCE | LOG-002 | settings.raw_response_logging | false | false | PASS | pending |
| ABC-DEMO-INFERENCE | AI-001 | settings.request_guardrails | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | AI-004 | settings.request_limits_enforced | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | AI-001 | settings.response_guardrails | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | K8S-001 | settings.run_as_non_root | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | PLAT-001 | settings.runtime | abc-managed-aks | abc-managed-aks | PASS | pending |
| ABC-DEMO-INFERENCE | SEC-002 | settings.secret_manager_ref | abc-secret-store | abc-secret-store | PASS | pending |
| ABC-DEMO-INFERENCE | LOG-001 | settings.security_events_logged | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | IAM-003 | settings.static_cloud_credentials | false | false | PASS | pending |
| ABC-DEMO-INFERENCE | PLAT-001 | settings.subscription_ref | ABC-SUBSCRIPTION-PLACEHOLDER | ABC-SUBSCRIPTION-PLACEHOLDER | PASS | pending |
| ABC-DEMO-INFERENCE | IAM-003 | settings.workload_identity | true | true | PASS | pending |
| ABC-DEMO-INFERENCE | AI-005 | evidence.AI-005 | null | null | PENDING | pending |
| ABC-DEMO-INFERENCE | GOV-001 | evidence.GOV-001 | null | null | PENDING | pending |
| ABC-DEMO-INFERENCE | GOV-002 | evidence.GOV-002 | null | null | PENDING | pending |
| ABC-DEMO-INFERENCE | OPS-001 | evidence.OPS-001 | null | null | PENDING | pending |
| ABC-DEMO-INFERENCE | RES-002 | evidence.RES-002 | null | null | PENDING | pending |
