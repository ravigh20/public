# ABC Security Patterns

**Eight reusable AI security patterns. One shared control catalog. Executable declaration tests.**

This is a small local starter for security architects. Edit YAML to define controls and pattern requirements; use Python to check their consistency and to validate a workload's declared settings. There are **8 pattern YAMLs + 1 shared `controls.yaml` = 9 YAML files**. All names use ABC, not a platform/employer name.

**This is not a diagramming or deployment tool. A passing check is not proof of implemented security, authorization to use a draft extension, or Security Authority approval.**

## Start here

Requires Python 3.11 or later. The included run was executed on Python 3.13.5/Linux with PyYAML 6.0.3 and pytest 9.0.2. Windows setup is provided but was not executed in this environment.

From the extracted `abc-security-patterns` directory:

```bash
python -m pip install -r requirements.txt
python validate.py --all
python -m pytest -q
python validate.py examples/managed-inference.json --report reports/my-review.md
```

Use a virtual environment before installing dependencies:

**Windows PowerShell — no activation-policy change required:**

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe validate.py --all
.\.venv\Scripts\python.exe -m pytest -q
```

**macOS/Linux:**

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python validate.py --all
.venv/bin/python -m pytest -q
```

Installation may need internet access to your approved package source. Ordinary checks make no network requests. Exact top-level dependency versions are pinned; this is not a transitive dependency lock or a vulnerability certification.

## The eight patterns

| File | What it adds |
|---|---|
| `patterns/abc-baseline.yaml` | Common identity, data, secrets, logging, incident and privacy requirements. |
| `patterns/abc-aks.yaml` | Designated subscription/AKS, workload identity, private access, egress, container isolation and image provenance. |
| `patterns/abc-inference.yaml` | Approved managed-model route, request/response guardrails, fail-closed behavior, request limits and evaluation requirements. |
| `patterns/abc-rag.yaml` | Per-document authorization, source permissions, untrusted retrieved content, index protection and deletion propagation. |
| `patterns/abc-agentic.yaml` | Scoped tools, per-action authorization, human approval for high-impact actions, budgets, sandboxing and action recovery. |
| `patterns/abc-mcp.yaml` | Authenticated remote HTTPS MCP, token audience checking, no token passthrough, tool authorization and connection protections. |
| `patterns/abc-model-hosting.yaml` | Alternative self-hosted model route, artifact integrity, safe loading, runtime isolation and model/runtime review. |
| `patterns/abc-saas-ai.yaml` | Tenant identity, AI entitlement, vendor data use, connector permissions, sharing and vendor assurance. |

The catalog contains **49 controls: 40 with executable declared-setting checks and 9 requiring human evidence review**. Even the 40 automated controls still require runtime/implementation evidence; their automated results only compare declarations.

## What each file means

- **`controls.yaml`: WHAT.** Control IDs, requirements, severity, verification mode and evidence needed. It does not store a project's approval or implementation status.
- **Pattern YAMLs: HOW.** Versioned control selections, concrete required settings, dependencies and implementation guidance.
- **A workload file: DECLARATION.** The patterns selected, actual claimed settings, enabled capabilities and evidence references for one proposed solution.
- **`policy.py`: REVIEWED FLOOR.** Small, explicit Python requirements independent of candidate YAML. Deleting a control, changing its verification mode or weakening a pattern does not make it pass.
- **`validate.py` and `tests/`: CHECKS.** Consistency checks plus positive, unsafe and incomplete scenarios.

A rule such as `response_guardrails: true` means this setting must be declared true. It does not demonstrate that every runtime response traverses a guardrail. The associated evidence requirement calls for the independent implementation tests.

Example from `abc-inference.yaml`:

```yaml
- control_id: AI-001
  implementation: Enforce approved request and response policies at the model access boundary.
  required_settings:
    request_guardrails: true
    response_guardrails: true
```

Turning `response_guardrails` off fails `AI-001` even when the control reference is retained. Removing that field yields `UNKNOWN`, not `PASS`.

## Pattern selection stays explicit

| Workload | Required patterns |
|---|---|
| Homegrown managed inference | BASELINE + AKS + INFERENCE |
| Homegrown managed inference with retrieval | BASELINE + AKS + INFERENCE + RAG |
| Homegrown agents using remote MCP | BASELINE + AKS + INFERENCE (or MODEL-HOSTING) + AGENTIC + MCP |
| Self-hosted model serving | BASELINE + AKS + MODEL-HOSTING |
| Vendor-operated SaaS AI | BASELINE + SAAS-AI |

Full IDs start with `ABC-`. Dependencies are additive. The workload must explicitly reference required patterns and versions. The validator independently determines the required set from the track, model mode and capabilities, so omitting a reference cannot switch off its rules.

Managed inference and self-hosted inference are alternatives in this single-route starter. Conflicting requirements are rejected; there is no last-writer-wins override.

SaaS does **not** inherit AKS, customer-managed private endpoint, workload identity or homegrown inference requirements. Its vendor-operated responsibilities require vendor evidence. Custom SaaS RAG, agents and MCP need additional SaaS-specific patterns; the homegrown extensions must not be applied blindly.

All patterns are drafts. RAG, agentic, MCP and self-hosting are proposed extensions, not enabled-by-default capabilities. Training/fine-tuning is outside scope. Remote HTTPS MCP is in scope; local stdio, dynamic client registration and public MCP publishing are not.

## Workload examples

Four JSON examples are included so the distribution keeps exactly nine YAML definition files. JSON is accepted by the same loader; workload inputs may also be ordinary YAML.

```bash
python validate.py examples/managed-inference.json
python validate.py examples/rag-agent-mcp.json
python validate.py examples/self-hosted.json
python validate.py examples/saas-ai.json
```

To start editing a workload in YAML, convert the synthetic example once:

```python
import json
import yaml
from pathlib import Path

sample = json.loads(Path("examples/managed-inference.json").read_text(encoding="utf-8"))
with open("examples/my-workload.yaml", "x", encoding="utf-8") as output:
    yaml.safe_dump(sample, output, sort_keys=False)
```

Then run `python validate.py examples/my-workload.yaml`.

The one-time conversion is an authoring convenience, not an assertion that a real workload has those settings. Replace every sample setting with the actual declaration; use `null` where it is unknown. Validation never fills missing candidate settings from the pattern to manufacture a pass.

Example files use synthetic identifiers: `ABC-SUBSCRIPTION-PLACEHOLDER`, `abc-managed-aks`, `abc-secret-store`, approved-route/registry names and a sample 10-step agent budget. Replace those policy values and update regression tests through reviewed changes before organizational adoption. None is a claim about a real service or an industry-prescribed limit.

## Results and reports

```bash
python validate.py --all --report reports/catalog-review.md
python validate.py examples/managed-inference.json --report reports/workload-review.md --json-report reports/workload-review.json
python validate.py --all --verbose
```

Reports identify the pattern/workload, control, YAML field, required/declared value, result and evidence state. Markdown reports are deterministic for unchanged input. They do not embed a current timestamp or a fabricated approval.

| Result | Meaning |
|---|---|
| PASS | The declared setting matches the proposed requirement. |
| FAIL | A value, reference, pattern selection or policy definition violates the registered requirement. |
| UNKNOWN | A required declaration is absent or null; design validation does not pass. |
| PENDING | Human evidence review is required. It is separate from design conformance. |

Exit codes: **0** design pass; **1** failed/unknown design; **2** malformed input, unsupported schema or operational error. Reports are still generated for policy failures/unknowns. Malformed files produce an input error before a report can be generated.

Evidence may be `pending` or `claimed`. A claim needs a reference but remains unverified. Files/URLs in evidence references are not fetched. This tool never marks evidence verified and always reports `implementation_assurance: UNVERIFIED` and `authorizes_release: false`.

AI Security owns assessment of supplied facts/evidence and follow-up remediation. Security Authority endorsement remains a separate human governance step; no local YAML field simulates it.

## Tests and a one-command check

```bash
python -m pytest -q
python -m pytest -q tests/test_patterns.py
python -m pytest -q tests/test_security.py
python check.py
```

`check.py` runs catalog validation, all four example validations and the full suite, stopping on failure. It does not install dependencies or access a cloud account.

Included tests cover duplicate keys/IDs, unknown fields/references, missing controls, contradictory patterns, dependency cycles, invalid types, unknown settings, profile omissions, guardrails, private access, identity, restricted data, logging, RAG, agents, MCP, model serving and SaaS separation. Tests use independent copies of nested data.

The packaged `reports/test-run.txt`, `reports/junit.xml` and `reports/control-test-coverage.md` record the executed run. Test-case counts are not a security/compliance score. The coverage table measures executed declaration tests, not protection against every attack.

## Editing and governance

Start by reading `controls.yaml` and one pattern. Workload authors ordinarily change only their workload declarations and evidence references.

Adding/changing a control or pattern is a policy change: update the catalog, corresponding pattern, explicit `policy.py` registration and independent regression cases, then run all tests. The starter intentionally supports one version (`1.0`); introducing another version requires an explicit validator/test change. It does not silently pick the latest version or merge conflicting requirements.

Use protected reviews/branch rules for `controls.yaml`, `patterns/`, `policy.py`, `validate.py` and `tests/`. Someone able to change both policy and tests can change what passes. This package does not configure GitHub protection, create a remote repository, push files or include a privileged workflow. The local GitHub-ready check command is `python check.py`.

## Limits

This checks declarations, not deployed Azure settings, live network routes, model safety, vendor truthfulness or runtime compliance. A field such as `direct_model_access: false` is a declaration, not a graph/reachability test. A prohibited-class list checks the proposed policy, not the contents of real prompts. Secret checks reject disallowed fields/values; they are not a full repository entropy/credential scan.

Manual controls are deliberately not converted into Boolean approval checkboxes. The set is a useful proposed starter, not an exhaustive security standard. There are no diagrams, image imports, UI, agents/LLM calls, deployments or cloud discovery.

## Primary implementation references

These informed parser/test implementation and the MCP-specific checks. They are not a compliance mapping or endorsement of this proposed ABC policy.

- PyYAML documentation, safe loading and constructors: https://pyyaml.org/wiki/PyYAMLDocumentation
- pytest documentation, parametrized tests and mutable-parameter behavior: https://docs.pytest.org/en/stable/how-to/parametrize.html
- MCP security best practices, token handling and remote integration threats (versioned reference): https://modelcontextprotocol.io/docs/2025-11-25/tutorials/security/security_best_practices
