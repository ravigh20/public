"""Run the same local checks on any supported operating system. No network access."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
COMMANDS = [
    ['validate.py', '--all'],
    ['validate.py', 'examples/managed-inference.json'],
    ['validate.py', 'examples/rag-agent-mcp.json'],
    ['validate.py', 'examples/self-hosted.json'],
    ['validate.py', 'examples/saas-ai.json'],
    ['-m', 'pytest', '-q'],
]


def main() -> int:
    for args in COMMANDS:
        print('\n> python ' + ' '.join(args), flush=True)
        result = subprocess.run([sys.executable, *args], cwd=ROOT, check=False)
        if result.returncode:
            return result.returncode
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
