from copy import deepcopy
import pytest
from validate import ROOT, load_repository, load_yaml


@pytest.fixture(scope='session')
def repository():
    return load_repository(ROOT)


@pytest.fixture
def repo(repository):
    # Deep copy is essential: nested mutations must never affect another test.
    return deepcopy(repository)


@pytest.fixture
def managed():
    return load_yaml(ROOT / 'examples' / 'managed-inference.json')


@pytest.fixture
def extended():
    return load_yaml(ROOT / 'examples' / 'rag-agent-mcp.json')


@pytest.fixture
def saas():
    return load_yaml(ROOT / 'examples' / 'saas-ai.json')
