"""Exercise every declared control-setting pair plus independent security regression cases."""
from copy import deepcopy
import pytest

from policy import PATTERN_RULES, RULES
from validate import InputError, compose, design_status, validate_repository

PAIRS = [(pid, cid, key) for pid, contract in PATTERN_RULES.items()
         for cid in contract['controls'] for key in RULES.get(cid, {})]
CONTROL_PAIRS = [(pid, cid) for pid, contract in PATTERN_RULES.items() for cid in contract['controls']]


def row(patterns, pid, cid):
    return next(c for c in patterns[pid]['controls'] if c['control_id'] == cid)


def bad_value(value):
    if type(value) is bool:
        return not value
    if type(value) is int:
        return value + 1
    if type(value) is list:
        return []
    return 'UNAPPROVED'


@pytest.mark.parametrize('pid,cid,key', PAIRS, ids=['-'.join(x) for x in PAIRS])
def test_setting_positive(repo, pid, cid, key):
    results = validate_repository(*repo)
    assert any(f.subject == pid and f.control_id == cid and f.field.endswith('.' + key)
               and f.status == 'PASS' for f in results)


@pytest.mark.parametrize('pid,cid,key', PAIRS, ids=['-'.join(x) for x in PAIRS])
def test_setting_negative(repo, pid, cid, key):
    catalog, patterns = repo
    required = row(patterns, pid, cid)['required_settings']
    required[key] = bad_value(required[key])
    results = validate_repository(catalog, patterns)
    assert any(f.subject == pid and f.control_id == cid and f.field.endswith('.' + key)
               and f.status == 'FAIL' for f in results)


@pytest.mark.parametrize('pid,cid,key', PAIRS, ids=['-'.join(x) for x in PAIRS])
def test_setting_missing_is_unknown(repo, pid, cid, key):
    catalog, patterns = repo
    del row(patterns, pid, cid)['required_settings'][key]
    results = validate_repository(catalog, patterns)
    assert any(f.subject == pid and f.control_id == cid and f.field.endswith('.' + key)
               and f.status == 'UNKNOWN' for f in results)
    assert design_status(results) == 'UNKNOWN'


@pytest.mark.parametrize('pid,cid', CONTROL_PAIRS)
def test_required_pattern_control_cannot_be_removed(repo, pid, cid):
    catalog, patterns = repo
    patterns[pid]['controls'] = [c for c in patterns[pid]['controls'] if c['control_id'] != cid]
    assert any(f.rule_id == 'CONTROL-MISSING' and f.control_id == cid and f.subject == pid
               for f in validate_repository(catalog, patterns))


# These expectations are explicit security decisions, not computed from input YAML or its findings.
@pytest.mark.parametrize('pid,cid,key,expected', [
    ('ABC-INFERENCE','AI-001','request_guardrails',True),
    ('ABC-INFERENCE','AI-001','response_guardrails',True),
    ('ABC-INFERENCE','AI-002','guardrails_fail_closed',True),
    ('ABC-INFERENCE','AI-003','public_model_endpoint',False),
    ('ABC-INFERENCE','AI-003','direct_model_access',False),
    ('ABC-AKS','IAM-003','workload_identity',True),
    ('ABC-AKS','NET-001','public_workload_endpoint',False),
    ('ABC-BASELINE','DATA-002','prohibited_data_classes',['PII','SI','HSI']),
    ('ABC-BASELINE','SEC-001','inline_secrets',False),
    ('ABC-BASELINE','LOG-002','raw_prompt_logging',False),
    ('ABC-RAG','RAG-001','retrieval_authorization_per_document',True),
    ('ABC-RAG','RAG-003','retrieved_instructions_executable',False),
    ('ABC-AGENTIC','AGT-002','high_impact_human_approval',True),
    ('ABC-AGENTIC','AGT-003','max_agent_steps',10),
    ('ABC-MCP','MCP-002','mcp_token_passthrough',False),
    ('ABC-MCP','MCP-002','mcp_token_audience_validation',True),
    ('ABC-MODEL-HOSTING','MOD-002','unsafe_model_deserialization',False),
    ('ABC-SAAS-AI','SAAS-002','saas_vendor_training_on_data',False),
])
def test_independent_security_regression(repo, pid, cid, key, expected):
    _, patterns = repo
    declared = row(patterns, pid, cid)['required_settings'][key]
    assert type(declared) is type(expected) and declared == expected
    assert RULES[cid][key] == expected


def test_dependency_deletion_is_detected(repo):
    catalog, patterns = repo
    patterns['ABC-AKS']['depends_on'] = []
    assert any(f.rule_id == 'DEPENDENCIES' for f in validate_repository(catalog, patterns))


def test_dependency_cycle_is_detected(repo):
    catalog, patterns = repo
    patterns['ABC-BASELINE']['depends_on'] = [{'id':'ABC-AKS','version':'1.0'}]
    assert any(f.rule_id == 'DEPENDENCY-CYCLE' for f in validate_repository(catalog, patterns))


def test_dependency_version_mismatch(repo):
    catalog, patterns = repo
    patterns['ABC-AKS']['depends_on'][0]['version'] = '2.0'
    assert any(f.rule_id == 'REFERENCE' for f in validate_repository(catalog, patterns))


def test_route_patterns_conflict_instead_of_silent_override(repo):
    _, patterns = repo
    with pytest.raises(InputError, match='Conflicting'):
        compose(patterns, ['ABC-INFERENCE','ABC-MODEL-HOSTING'])


def test_composition_is_order_independent(repo):
    _, patterns = repo
    ids = ['ABC-BASELINE','ABC-AKS','ABC-INFERENCE','ABC-RAG','ABC-AGENTIC','ABC-MCP']
    assert compose(patterns, ids) == compose(patterns, list(reversed(ids)))


def test_unknown_control_reference(repo):
    catalog, patterns = repo
    patterns['ABC-INFERENCE']['controls'][0]['control_id'] = 'UNKNOWN-999'
    assert any(f.rule_id == 'CONTROL-REFERENCE' for f in validate_repository(catalog, patterns))


def test_duplicate_control_reference(repo):
    catalog, patterns = repo
    patterns['ABC-INFERENCE']['controls'].append(deepcopy(patterns['ABC-INFERENCE']['controls'][0]))
    with pytest.raises(InputError, match='duplicate control reference'):
        validate_repository(catalog, patterns)


def test_unknown_setting_is_not_ignored(repo):
    catalog, patterns = repo
    row(patterns,'ABC-INFERENCE','AI-001')['required_settings']['ignore_guardrails'] = True
    assert any(f.rule_id == 'SETTING-UNKNOWN' for f in validate_repository(catalog, patterns))


def test_changing_track_cannot_remove_controls(repo):
    catalog, patterns = repo
    patterns['ABC-AKS']['track'] = 'saas'
    assert any(f.rule_id == 'PATTERN-TRACK' for f in validate_repository(catalog, patterns))


def test_empty_pattern_repository_fails(repo):
    catalog, _ = repo
    assert design_status(validate_repository(catalog, {})) == 'FAIL'


def test_all_eight_pattern_files_are_mandatory(repo):
    catalog, patterns = repo
    assert len(patterns) == 8
    del patterns['ABC-MCP']
    assert any(f.rule_id == 'PATTERN-MISSING' and f.subject == 'ABC-MCP'
               for f in validate_repository(catalog, patterns))
