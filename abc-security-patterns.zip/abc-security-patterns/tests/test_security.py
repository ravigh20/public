"""Declared workload scenarios: valid, unsafe, incomplete and track-specific."""
from copy import deepcopy
import pytest

from policy import MANUAL_CONTROLS
from validate import ROOT, InputError, design_status, load_yaml, summary, validate_workload


@pytest.mark.parametrize('filename', ['managed-inference.json','rag-agent-mcp.json','self-hosted.json','saas-ai.json'])
def test_proposed_examples_pass_design_but_not_assurance(repo, filename):
    doc = load_yaml(ROOT / 'examples' / filename)
    result = summary(validate_workload(doc, *repo))
    assert result['design_status'] == 'PASS'
    assert result['implementation_assurance'] == 'UNVERIFIED'
    assert result['authorizes_release'] is False
    assert result['counts']['PENDING'] > 0


@pytest.mark.parametrize('field,bad,control', [
    ('request_guardrails',False,'AI-001'),
    ('response_guardrails',False,'AI-001'),
    ('guardrails_fail_closed',False,'AI-002'),
    ('direct_model_access',True,'AI-003'),
    ('public_model_endpoint',True,'AI-003'),
    ('model_route','unapproved-provider','AI-003'),
    ('public_workload_endpoint',True,'NET-001'),
    ('controlled_egress',False,'NET-002'),
    ('workload_identity',False,'IAM-003'),
    ('authorization_enforced',False,'IAM-001'),
    ('encryption_in_transit',False,'DATA-001'),
    ('encryption_at_rest',False,'DATA-001'),
    ('prohibited_data_classes',['SI','HSI'],'DATA-002'),
    ('inline_secrets',True,'SEC-001'),
    ('secret_manager_ref','unapproved-store','SEC-002'),
    ('raw_prompt_logging',True,'LOG-002'),
    ('raw_response_logging',True,'LOG-002'),
    ('audit_export_enabled',False,'LOG-001'),
    ('runtime','standalone-vm','PLAT-001'),
    ('subscription_ref','outside-subscription','PLAT-001'),
    ('image_verification_required',False,'SUP-001'),
    ('kill_switch_available',False,'RES-001'),
])
def test_unsafe_workload_field_fails_expected_control(repo, managed, field, bad, control):
    managed['settings'][field] = bad
    findings = validate_workload(managed, *repo)
    assert any(f.control_id == control and f.field == 'settings.' + field and f.status == 'FAIL'
               for f in findings)
    assert design_status(findings) == 'FAIL'


@pytest.mark.parametrize('field', ['request_guardrails','response_guardrails','workload_identity','public_workload_endpoint'])
@pytest.mark.parametrize('bad', ['true','false','not_applicable',1,0,[],{}])
def test_types_cannot_bypass_boolean_checks(repo, managed, field, bad):
    managed['settings'][field] = bad
    findings = validate_workload(managed, *repo)
    assert any(f.field == 'settings.' + field and f.status == 'FAIL' for f in findings)


@pytest.mark.parametrize('mode', ['missing','null'])
def test_absent_response_guardrail_is_unknown_not_pass(repo, managed, mode):
    if mode == 'missing':
        del managed['settings']['response_guardrails']
    else:
        managed['settings']['response_guardrails'] = None
    findings = validate_workload(managed, *repo)
    assert design_status(findings) == 'UNKNOWN'
    assert any(f.control_id == 'AI-001' and f.field == 'settings.response_guardrails' and f.status == 'UNKNOWN'
               for f in findings)


def test_omitting_inference_pattern_does_not_disable_its_rules(repo, managed):
    managed['patterns'] = [p for p in managed['patterns'] if p['id'] != 'ABC-INFERENCE']
    managed['settings']['response_guardrails'] = False
    findings = validate_workload(managed, *repo)
    assert any(f.rule_id == 'PATTERN-MISSING' for f in findings)
    assert any(f.control_id == 'AI-001' and f.status == 'FAIL' for f in findings)


@pytest.mark.parametrize('capability,pattern', [('rag','ABC-RAG'),('agentic','ABC-AGENTIC'),('mcp','ABC-MCP')])
def test_feature_enablement_requires_extension(repo, managed, capability, pattern):
    managed['capabilities'][capability] = True
    findings = validate_workload(managed, *repo)
    assert any(f.rule_id == 'PATTERN-MISSING' and pattern in f.message for f in findings)


@pytest.mark.parametrize('field,control', [
    ('retrieval_authorization_per_document','RAG-001'),
    ('retrieval_tenant_isolation','RAG-001'),
    ('source_acl_propagation','RAG-002'),
    ('high_impact_human_approval','AGT-002'),
    ('mcp_token_audience_validation','MCP-002'),
    ('mcp_server_allowlist','MCP-003'),
    ('mcp_ssrf_protection','MCP-005'),
])
def test_extension_rules_are_enforced(repo, extended, field, control):
    extended['settings'][field] = False
    assert any(f.control_id == control and f.field == 'settings.' + field and f.status == 'FAIL'
               for f in validate_workload(extended, *repo))


def test_mcp_passthrough_rejected(repo, extended):
    extended['settings']['mcp_token_passthrough'] = True
    assert any(f.control_id == 'MCP-002' and f.status == 'FAIL' for f in validate_workload(extended, *repo))


def test_step_budget_integer_does_not_accept_boolean(repo, extended):
    extended['settings']['max_agent_steps'] = True
    assert any(f.control_id == 'AGT-003' and f.status == 'FAIL' for f in validate_workload(extended, *repo))


def test_manual_claim_is_still_pending(repo, managed):
    managed['evidence']['GOV-001'] = {'status':'claimed','reference':'evidence:incident-runbook'}
    findings = validate_workload(managed, *repo)
    assert any(f.control_id == 'GOV-001' and f.status == 'PENDING' and f.evidence == 'claimed' for f in findings)
    assert summary(findings)['implementation_assurance'] == 'UNVERIFIED'


def test_verified_yaml_claim_is_not_accepted(repo, managed):
    managed['evidence']['AI-001'] = {'status':'verified','reference':'made-up-approval'}
    with pytest.raises(InputError, match='cannot verify'):
        validate_workload(managed, *repo)


def test_claimed_evidence_needs_a_reference(repo, managed):
    managed['evidence']['AI-001'] = {'status':'claimed','reference':None}
    with pytest.raises(InputError, match='requires a reference'):
        validate_workload(managed, *repo)


def test_no_evidence_does_not_create_a_runtime_pass(repo, managed):
    del managed['evidence']
    result = summary(validate_workload(managed, *repo))
    assert result['design_status'] == 'PASS'
    assert result['implementation_assurance'] == 'UNVERIFIED'
    assert all(f['evidence'] == 'pending' for f in result['findings'])


def test_saas_does_not_require_aks_private_endpoints_or_workload_identity(repo, saas):
    findings = validate_workload(saas, *repo)
    assert design_status(findings) == 'PASS'
    assert not any(f.control_id in {'PLAT-001','NET-001','IAM-003'} for f in findings)


def test_saas_training_on_customer_data_fails(repo, saas):
    saas['settings']['saas_vendor_training_on_data'] = True
    assert any(f.control_id == 'SAAS-002' and f.status == 'FAIL' for f in validate_workload(saas, *repo))


@pytest.mark.parametrize('capability', ['rag','mcp','agentic','training'])
def test_unsupported_saas_extension_cannot_use_homegrown_pattern(repo, saas, capability):
    saas['capabilities'][capability] = True
    assert any(f.rule_id == 'CAPABILITY-UNSUPPORTED' for f in validate_workload(saas, *repo))


def test_training_is_out_of_scope(repo, managed):
    managed['capabilities']['training'] = True
    assert any(f.rule_id == 'CAPABILITY-UNSUPPORTED' for f in validate_workload(managed, *repo))


def test_unknown_capability_blocks_design(repo, managed):
    managed['capabilities']['rag'] = None
    assert design_status(validate_workload(managed, *repo)) == 'UNKNOWN'


def test_missing_capability_is_input_error(repo, managed):
    del managed['capabilities']['mcp']
    with pytest.raises(InputError, match='missing fields'):
        validate_workload(managed, *repo)


def test_unknown_inline_credential_key_is_rejected_without_echo(repo, managed):
    managed['settings']['api_key'] = 'SYNTHETIC_DO_NOT_ECHO'
    findings = validate_workload(managed, *repo)
    assert any(f.rule_id == 'SETTING-UNKNOWN' and f.field == 'settings.api_key' for f in findings)
    assert 'SYNTHETIC_DO_NOT_ECHO' not in str(summary(findings))


def test_list_order_irrelevant_but_duplicates_fail(repo, managed):
    managed['settings']['prohibited_data_classes'] = ['HSI','SI','PII']
    assert design_status(validate_workload(managed, *repo)) == 'PASS'
    managed['settings']['prohibited_data_classes'].append('PII')
    assert any(f.control_id == 'DATA-002' and f.status == 'FAIL' for f in validate_workload(managed, *repo))


def test_forged_approval_field_rejected(repo, managed):
    managed['authorizes_release'] = True
    with pytest.raises(InputError, match='unknown fields'):
        validate_workload(managed, *repo)


def test_workload_validation_does_not_modify_source(repo, managed):
    before = deepcopy(managed)
    validate_workload(managed, *repo)
    assert managed == before


def test_unknown_pattern_version_fails(repo, managed):
    managed['patterns'][0]['version'] = '9.0'
    assert any(f.rule_id == 'PATTERN-REFERENCE' for f in validate_workload(managed, *repo))


def test_invalid_catalog_blocks_workload_evaluation(repo, managed):
    catalog, patterns = repo
    del patterns['ABC-MCP']
    assert validate_workload(managed, catalog, patterns)[0].rule_id == 'POLICY-INVALID'
