from copy import deepcopy
from dataclasses import asdict
import json
from pathlib import Path
import shutil
import subprocess
import sys
import pytest
import yaml

from validate import ROOT, Finding, InputError, design_status, load_repository, load_yaml, main, markdown, write_report


def run(*args):
    return subprocess.run([sys.executable, str(ROOT / 'validate.py'), *map(str, args)],
                          cwd=ROOT, capture_output=True, text=True, timeout=30)


def test_catalog_cli():
    result = run('--all')
    assert result.returncode == 0
    assert 'Design: PASS' in result.stdout
    assert 'UNVERIFIED' in result.stdout


def test_invalid_workload_cli_writes_report_and_exits_one(managed, tmp_path):
    managed['settings']['response_guardrails'] = False
    source = tmp_path / 'candidate.yaml'
    source.write_text(yaml.safe_dump(managed), encoding='utf-8')
    report = tmp_path / 'reports' / 'failure.md'
    json_report = tmp_path / 'reports' / 'failure.json'
    result = run(source, '--report', report, '--json-report', json_report)
    assert result.returncode == 1
    assert 'AI-001' in result.stdout and 'settings.response_guardrails' in result.stdout
    assert 'FAIL' in report.read_text(encoding='utf-8')
    assert json.loads(json_report.read_text())['design_status'] == 'FAIL'


def test_unknown_setting_cli_exits_one(managed, tmp_path):
    del managed['settings']['response_guardrails']
    source = tmp_path / 'candidate.json'
    source.write_text(json.dumps(managed))
    result = run(source)
    assert result.returncode == 1 and 'Design: UNKNOWN' in result.stdout


def test_missing_file_cli_exits_two(tmp_path):
    result = run(tmp_path / 'not-there.yaml')
    assert result.returncode == 2 and 'INPUT ERROR' in result.stderr


def test_wrong_command_arguments_fail():
    assert run('--all', ROOT / 'examples' / 'managed-inference.json').returncode == 2


def test_yaml_and_json_workload_equivalence(managed, tmp_path):
    path = tmp_path / 'workload.yaml'
    path.write_text(yaml.safe_dump(managed), encoding='utf-8')
    assert load_yaml(path) == managed


def test_report_is_deterministic(repo):
    from validate import validate_repository
    findings = validate_repository(*repo)
    assert markdown(findings, 'Review') == markdown(findings, 'Review')


def test_report_escapes_markdown_html():
    finding = Finding('TEST','FAIL','<script>x</script>','field|value','<img src=x>')
    output = markdown([finding], '<b>Title</b>')
    assert '<script>' not in output and '<img' not in output and '<b>' not in output
    assert r'field\|value' in output


def test_empty_results_are_unknown_not_pass():
    assert design_status([]) == 'UNKNOWN'


def test_missing_pattern_file_detected(tmp_path):
    shutil.copy(ROOT / 'controls.yaml', tmp_path / 'controls.yaml')
    (tmp_path / 'patterns').mkdir()
    catalog, patterns = load_repository(tmp_path)
    from validate import validate_repository
    assert design_status(validate_repository(catalog, patterns)) == 'FAIL'


def test_schema_version_is_explicit(repo):
    from validate import validate_repository
    catalog, patterns = repo
    patterns['ABC-AKS']['schema_version'] = '2.0'
    with pytest.raises(InputError, match='unsupported'):
        validate_repository(catalog, patterns)


def test_report_does_not_overwrite_source(tmp_path):
    readme = tmp_path / 'README.md'
    readme.write_text('original')
    with pytest.raises(InputError, match='Refusing'):
        write_report(readme, 'replacement')
    assert readme.read_text() == 'original'


def test_invalid_report_extension(tmp_path):
    with pytest.raises(InputError, match='extension'):
        write_report(tmp_path / 'controls.yaml', 'overwrite')


def test_report_traversal_does_not_overwrite_source(tmp_path):
    (tmp_path / 'reports').mkdir()
    readme = tmp_path / 'README.md'
    readme.write_text('original')
    with pytest.raises(InputError, match='Refusing'):
        write_report(tmp_path / 'reports' / '..' / 'README.md', 'replacement')
    assert readme.read_text() == 'original'
