"""Catalog contracts and safe input handling; manual reviews are not automated approvals."""
from copy import deepcopy
import pytest

from policy import MANUAL_CONTROLS, RULES
from validate import InputError, catalog_shape, design_status, parse_yaml, validate_repository


@pytest.mark.parametrize('control_id', sorted(set(RULES) | set(MANUAL_CONTROLS)))
def test_every_mandatory_control_cannot_be_deleted(repo, control_id):
    catalog, patterns = repo
    catalog['controls'] = [c for c in catalog['controls'] if c['id'] != control_id]
    findings = validate_repository(catalog, patterns)
    assert any(f.rule_id == 'CATALOG-MISSING' and f.control_id == control_id and f.status == 'FAIL'
               for f in findings)


@pytest.mark.parametrize('control_id', sorted(RULES))
def test_automated_control_cannot_become_a_manual_claim(repo, control_id):
    catalog, patterns = repo
    next(c for c in catalog['controls'] if c['id'] == control_id)['verification'] = 'manual_evidence'
    assert any(f.rule_id == 'VERIFICATION-MODE' and f.control_id == control_id
               for f in validate_repository(catalog, patterns))


def test_duplicate_control_id_rejected(repo):
    catalog, _ = repo
    catalog['controls'].append(deepcopy(catalog['controls'][0]))
    with pytest.raises(InputError, match='duplicate control'):
        catalog_shape(catalog)


def test_unknown_control_has_no_silent_default_evaluator(repo):
    catalog, patterns = repo
    new = deepcopy(catalog['controls'][0])
    new['id'] = 'NEW-001'
    catalog['controls'].append(new)
    findings = validate_repository(catalog, patterns)
    assert any(f.rule_id == 'CATALOG-UNSUPPORTED' and f.control_id == 'NEW-001' for f in findings)


@pytest.mark.parametrize('field,value', [('approved', True), ('ignore_findings', True), ('extra', {})])
def test_unknown_catalog_fields_rejected(repo, field, value):
    catalog, _ = repo
    catalog[field] = value
    with pytest.raises(InputError, match='unknown fields'):
        catalog_shape(catalog)


def test_catalog_manual_controls_remain_pending(repo):
    findings = validate_repository(*repo)
    assert design_status(findings) == 'PASS'
    assert {f.control_id for f in findings if f.status == 'PENDING'} == set(MANUAL_CONTROLS)
    assert not any(f.status == 'PASS' and f.control_id in MANUAL_CONTROLS for f in findings)


@pytest.mark.parametrize('payload', [
    'a: 1\na: 2\n',
    'nested:\n  key: true\n  key: false\n',
    'a: &value [1]\nb: *value\n',
    'a: !!python/object/apply:os.system ["echo SHOULD_NOT_RUN"]\n',
    'a: !custom anything\n',
    'a: 1\n---\nb: 2\n',
    '- not\n- a\n- mapping\n',
    '1: integer-key\n',
    'a: .nan\n',
    'a: !!binary aGVsbG8=\n',
    '',
])
def test_unsafe_or_ambiguous_yaml_is_rejected(payload):
    with pytest.raises(InputError):
        parse_yaml(payload)


def test_depth_limit():
    with pytest.raises(InputError, match='nesting'):
        parse_yaml('x: ' + '[' * 34 + '1' + ']' * 34)


def test_input_size_limit():
    with pytest.raises(InputError, match='1 MB'):
        parse_yaml('x: ' + 'a' * 1_000_001)


def test_event_count_limit():
    with pytest.raises(InputError, match='events'):
        parse_yaml('x: [' + ','.join('1' for _ in range(21_000)) + ']')


def test_only_explicit_lowercase_booleans_are_parsed():
    doc = parse_yaml('a: true\nb: false\nc: yes\nd: no\ne: "false"\nf: TRUE\n')
    assert doc == {'a': True, 'b': False, 'c': 'yes', 'd': 'no', 'e': 'false', 'f': 'TRUE'}


def test_malformed_error_does_not_echo_raw_secret():
    with pytest.raises(InputError) as exc:
        parse_yaml('password: [DO_NOT_PRINT_THIS_SECRET')
    assert 'DO_NOT_PRINT_THIS_SECRET' not in str(exc.value)
