"""Reviewed minimum rules for the proposed ABC profiles; never derived from candidate YAML.
Changing this file is a security-policy change, not an application configuration change.
String identifiers and the ten-step budget are synthetic starter policy choices.
"""

RULES = {
    'IAM-001': {'enterprise_authentication': True, 'authorization_enforced': True},
    'IAM-002': {'least_privilege': True, 'privileged_access_time_bound': True},
    'DATA-001': {'encryption_in_transit': True, 'encryption_at_rest': True},
    'DATA-002': {'prohibited_data_classes': ['PII', 'SI', 'HSI'], 'classification_enforced': True},
    'SEC-001': {'inline_secrets': False},
    'LOG-001': {'security_events_logged': True, 'audit_export_enabled': True},
    'LOG-002': {'raw_prompt_logging': False, 'raw_response_logging': False},
    'RES-001': {'kill_switch_available': True},
    'PLAT-001': {'subscription_ref': 'ABC-SUBSCRIPTION-PLACEHOLDER', 'runtime': 'abc-managed-aks'},
    'IAM-003': {'workload_identity': True, 'static_cloud_credentials': False},
    'NET-001': {'public_workload_endpoint': False},
    'NET-002': {'controlled_egress': True, 'egress_policy_ref': 'abc-egress-allowlist'},
    'SEC-002': {'secret_manager_ref': 'abc-secret-store'},
    'K8S-001': {'run_as_non_root': True, 'privileged_containers': False},
    'K8S-002': {'namespace_rbac': True, 'default_deny_network_policy': True},
    'SUP-001': {'image_registry_ref': 'abc-approved-registry', 'image_digest_pinning': True, 'image_verification_required': True},
    'AI-001': {'request_guardrails': True, 'response_guardrails': True},
    'AI-002': {'guardrails_fail_closed': True},
    'AI-003': {'model_route': 'abc-managed-model-route', 'public_model_endpoint': False, 'direct_model_access': False},
    'AI-004': {'request_limits_enforced': True, 'provider_training_on_customer_data': False},
    'RAG-001': {'retrieval_authorization_per_document': True, 'retrieval_tenant_isolation': True},
    'RAG-002': {'rag_sources_allowlisted': True, 'source_acl_propagation': True},
    'RAG-003': {'retrieved_content_untrusted': True, 'retrieved_instructions_executable': False},
    'RAG-004': {'vector_store_private_access': True, 'document_deletion_propagation': True},
    'AGT-001': {'tools_allowlisted': True, 'tool_permissions_scoped': True},
    'AGT-002': {'authorization_per_action': True, 'high_impact_human_approval': True},
    'AGT-003': {'max_agent_steps': 10, 'execution_budget_enforced': True},
    'AGT-004': {'sandboxed_execution': True, 'arbitrary_shell_execution': False},
    'MCP-001': {'mcp_transport': 'https', 'mcp_server_authentication': True},
    'MCP-002': {'mcp_token_audience_validation': True, 'mcp_token_passthrough': False},
    'MCP-003': {'mcp_server_allowlist': True, 'mcp_per_tool_authorization': True},
    'MCP-004': {'mcp_tool_schema_validation': True, 'mcp_tool_changes_require_review': True},
    'MCP-005': {'mcp_ssrf_protection': True, 'mcp_consent_at_authorization': True, 'mcp_redirect_exact_match': True},
    'MOD-001': {'model_route': 'abc-self-hosted-model-route', 'public_model_endpoint': False, 'direct_model_access': False},
    'MOD-002': {'model_registry_ref': 'abc-approved-model-registry', 'model_digest_pinning': True, 'unsafe_model_deserialization': False},
    'MOD-003': {'isolated_model_runtime': True, 'model_training_enabled': False},
    'SAAS-001': {'saas_sso_enforced': True, 'saas_ai_access_restricted': True},
    'SAAS-002': {'saas_vendor_training_on_data': False, 'saas_retention_configured': True},
    'SAAS-003': {'saas_connector_scope_minimized': True, 'saas_source_permissions_preserved': True},
    'SAAS-004': {'saas_public_sharing': False, 'saas_tenant_audit_enabled': True},
}

MANUAL_CONTROLS = frozenset(['GOV-001','GOV-002','OPS-001','RES-002','AI-005','AGT-005','MOD-004','SAAS-005','SAAS-006'])

PATTERN_RULES = {
    'ABC-BASELINE': {'filename': 'abc-baseline.yaml', 'track': 'common', 'dependencies': [], 'controls': ['IAM-001', 'IAM-002', 'DATA-001', 'DATA-002', 'SEC-001', 'LOG-001', 'LOG-002', 'RES-001', 'GOV-001', 'GOV-002']},
    'ABC-AKS': {'filename': 'abc-aks.yaml', 'track': 'homegrown', 'dependencies': ['ABC-BASELINE'], 'controls': ['PLAT-001', 'IAM-003', 'NET-001', 'NET-002', 'SEC-002', 'K8S-001', 'K8S-002', 'SUP-001', 'OPS-001', 'RES-002']},
    'ABC-INFERENCE': {'filename': 'abc-inference.yaml', 'track': 'homegrown', 'dependencies': ['ABC-BASELINE', 'ABC-AKS'], 'controls': ['AI-001', 'AI-002', 'AI-003', 'AI-004', 'AI-005']},
    'ABC-RAG': {'filename': 'abc-rag.yaml', 'track': 'homegrown', 'dependencies': ['ABC-BASELINE', 'ABC-AKS'], 'controls': ['RAG-001', 'RAG-002', 'RAG-003', 'RAG-004']},
    'ABC-AGENTIC': {'filename': 'abc-agentic.yaml', 'track': 'homegrown', 'dependencies': ['ABC-BASELINE', 'ABC-AKS'], 'controls': ['AGT-001', 'AGT-002', 'AGT-003', 'AGT-004', 'AGT-005']},
    'ABC-MCP': {'filename': 'abc-mcp.yaml', 'track': 'homegrown', 'dependencies': ['ABC-BASELINE', 'ABC-AKS'], 'controls': ['MCP-001', 'MCP-002', 'MCP-003', 'MCP-004', 'MCP-005']},
    'ABC-MODEL-HOSTING': {'filename': 'abc-model-hosting.yaml', 'track': 'homegrown', 'dependencies': ['ABC-BASELINE', 'ABC-AKS'], 'controls': ['AI-001', 'AI-002', 'AI-005', 'MOD-001', 'MOD-002', 'MOD-003', 'MOD-004']},
    'ABC-SAAS-AI': {'filename': 'abc-saas-ai.yaml', 'track': 'saas', 'dependencies': ['ABC-BASELINE'], 'controls': ['SAAS-001', 'SAAS-002', 'SAAS-003', 'SAAS-004', 'SAAS-005', 'SAAS-006']},
}

CAPABILITY_PATTERNS = {"rag": "ABC-RAG", "agentic": "ABC-AGENTIC", "mcp": "ABC-MCP"}
SUPPORTED_VERSION = "1.0"
