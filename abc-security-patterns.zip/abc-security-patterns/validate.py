"""Local declaration checks for ABC controls/patterns. No cloud access or approval logic."""
from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path
import re
import sys
from typing import Any

import yaml
from yaml.events import AliasEvent, MappingStartEvent, SequenceStartEvent
from yaml.events import MappingEndEvent, SequenceEndEvent

from policy import CAPABILITY_PATTERNS, MANUAL_CONTROLS, PATTERN_RULES, RULES, SUPPORTED_VERSION

ROOT = Path(__file__).resolve().parent
MAX_BYTES = 1_000_000


class InputError(ValueError):
    """Malformed, unsupported, or unsafe input (CLI exit 2)."""


class StrictLoader(yaml.SafeLoader):
    """SafeLoader with duplicate-key rejection and only true/false booleans."""


StrictLoader.yaml_implicit_resolvers = deepcopy(yaml.SafeLoader.yaml_implicit_resolvers)
for initial, resolvers in StrictLoader.yaml_implicit_resolvers.items():
    StrictLoader.yaml_implicit_resolvers[initial] = [
        (tag, regex) for tag, regex in resolvers
        if tag not in {'tag:yaml.org,2002:bool', 'tag:yaml.org,2002:timestamp'}
    ]
StrictLoader.add_implicit_resolver(
    'tag:yaml.org,2002:bool', re.compile(r'^(?:true|false)$'), list('tf')
)


def _mapping(loader: StrictLoader, node: yaml.Node) -> dict:
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=True)
        if type(key) is not str:
            raise InputError(f'Line {key_node.start_mark.line + 1}: mapping keys must be strings.')
        if key in result:
            raise InputError(f'Line {key_node.start_mark.line + 1}: duplicate YAML key {key!r}.')
        result[key] = loader.construct_object(value_node, deep=True)
    return result


StrictLoader.add_constructor('tag:yaml.org,2002:map', _mapping)


def parse_yaml(text: str, source: str = '<input>') -> dict:
    """JSON is also accepted because it is a subset of the supported YAML syntax."""
    if len(text.encode('utf-8')) > MAX_BYTES:
        raise InputError(f'{source}: exceeds 1 MB input limit.')
    depth = count = 0
    try:
        for event in yaml.parse(text):
            count += 1
            if count > 20_000:
                raise InputError(f'{source}: too many YAML events.')
            if isinstance(event, AliasEvent) or getattr(event, 'anchor', None):
                raise InputError(f'{source}: YAML anchors/aliases are not supported.')
            if isinstance(event, (MappingStartEvent, SequenceStartEvent)):
                depth += 1
                if depth > 32:
                    raise InputError(f'{source}: nesting exceeds 32 levels.')
            elif isinstance(event, (MappingEndEvent, SequenceEndEvent)):
                depth -= 1
        value = yaml.load(text, Loader=StrictLoader)
    except yaml.YAMLError as exc:
        # Do not echo potentially secret-bearing raw input in errors.
        mark = getattr(exc, 'problem_mark', None)
        position = f' at line {mark.line + 1}' if mark is not None else ''
        raise InputError(f'{source}: invalid or unsupported YAML{position}.') from exc
    if type(value) is not dict:
        raise InputError(f'{source}: expected one YAML mapping document.')
    _json_values(value, source)
    return value


def _json_values(value: Any, path: str) -> None:
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float and math.isfinite(value):
        return
    if type(value) is list:
        for i, item in enumerate(value):
            _json_values(item, f'{path}[{i}]')
        return
    if type(value) is dict:
        for key, item in value.items():
            _json_values(item, f'{path}.{key}')
        return
    raise InputError(f'{path}: only finite JSON-compatible values are supported.')


def load_yaml(path: Path | str) -> dict:
    path = Path(path)
    try:
        with path.open('rb') as handle:
            raw = handle.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES:
            raise InputError(f'{path.name}: exceeds 1 MB input limit.')
        return parse_yaml(raw.decode('utf-8-sig'), path.name)
    except (OSError, UnicodeError) as exc:
        raise InputError(f'{path.name}: file unavailable or not valid UTF-8.') from exc


def shape(value: Any, required: set[str], optional: set[str], path: str) -> None:
    if type(value) is not dict:
        raise InputError(f'{path}: expected a mapping.')
    missing, extra = required - value.keys(), value.keys() - required - optional
    if missing or extra:
        raise InputError(f'{path}: missing fields={sorted(missing)}; unknown fields={sorted(extra)}.')


def text(value: Any, path: str) -> None:
    if type(value) is not str or not value.strip():
        raise InputError(f'{path}: expected a nonempty string.')


def items(value: Any, path: str, nonempty: bool = False) -> list:
    if type(value) is not list or (nonempty and not value):
        raise InputError(f'{path}: expected {"a nonempty" if nonempty else "a"} list.')
    return value


def references(value: Any, path: str) -> None:
    seen = set()
    for i, ref in enumerate(items(value, path)):
        prefix = f'{path}[{i}]'
        shape(ref, {'id', 'version'}, set(), prefix)
        text(ref['id'], prefix + '.id')
        text(ref['version'], prefix + '.version')
        if ref['id'] in seen:
            raise InputError(f'{prefix}: duplicate reference {ref["id"]}.')
        seen.add(ref['id'])


def catalog_shape(doc: dict) -> None:
    shape(doc, {'schema_version', 'catalog_version', 'name', 'controls'}, set(), 'controls.yaml')
    if doc['schema_version'] != SUPPORTED_VERSION or doc['catalog_version'] != SUPPORTED_VERSION:
        raise InputError('controls.yaml: unsupported schema/catalog version.')
    text(doc['name'], 'controls.yaml.name')
    seen = set()
    for i, control in enumerate(items(doc['controls'], 'controls', nonempty=True)):
        path = f'controls[{i}]'
        shape(control, {'id', 'name', 'category', 'severity', 'requirement',
                        'verification', 'evidence_required'}, set(), path)
        for field in ('id', 'name', 'category', 'requirement'):
            text(control[field], path + '.' + field)
        if not re.fullmatch(r'[A-Z][A-Z0-9]*-\d{3}', control['id']):
            raise InputError(f'{path}.id: expected an ID such as IAM-001.')
        if control['id'] in seen:
            raise InputError(f'{path}: duplicate control ID.')
        seen.add(control['id'])
        if control['severity'] not in ('critical', 'high', 'medium', 'low'):
            raise InputError(f'{path}: invalid severity.')
        if control['verification'] not in ('declared_settings', 'manual_evidence'):
            raise InputError(f'{path}: unsupported verification mode.')
        for evidence in items(control['evidence_required'], path + '.evidence_required', True):
            text(evidence, path + '.evidence_required')


def pattern_shape(doc: dict, filename: str) -> None:
    shape(doc, {'schema_version', 'id', 'version', 'status', 'name', 'track',
                'description', 'depends_on', 'controls', 'notes'}, set(), filename)
    for field in ('id', 'version', 'name', 'description'):
        text(doc[field], f'{filename}.{field}')
    if doc['schema_version'] != SUPPORTED_VERSION or doc['version'] != SUPPORTED_VERSION:
        raise InputError(f'{filename}: unsupported schema/pattern version.')
    if doc['status'] != 'draft':
        raise InputError(f'{filename}: this starter accepts draft patterns, not approval assertions.')
    if doc['track'] not in ('common', 'homegrown', 'saas'):
        raise InputError(f'{filename}: unsupported track.')
    references(doc['depends_on'], filename + '.depends_on')
    for note in items(doc['notes'], filename + '.notes'):
        text(note, filename + '.notes')
    seen = set()
    for i, control in enumerate(items(doc['controls'], filename + '.controls', True)):
        path = f'{filename}.controls[{i}]'
        shape(control, {'control_id', 'implementation', 'required_settings'}, set(), path)
        text(control['control_id'], path + '.control_id')
        text(control['implementation'], path + '.implementation')
        if control['control_id'] in seen:
            raise InputError(f'{path}: duplicate control reference.')
        seen.add(control['control_id'])
        if type(control['required_settings']) is not dict:
            raise InputError(f'{path}.required_settings: expected a mapping.')


@dataclass(frozen=True)
class Finding:
    rule_id: str
    status: str
    subject: str
    field: str
    message: str
    control_id: str = ''
    required: Any = None
    declared: Any = None
    evidence: str = 'pending'
    remediation: str = 'Review the requirement and correct the declaration; supply independent evidence.'


def same(actual: Any, expected: Any) -> bool:
    """Strict scalar types; allow reordered but not duplicated string-set values."""
    if type(actual) is not type(expected):
        return False
    if type(expected) is list:
        return (all(type(x) is str for x in actual)
                and len(actual) == len(set(actual)) and set(actual) == set(expected))
    return actual == expected


def setting_result(subject: str, control: str, path: str, expected: Any, actual: Any) -> Finding:
    status = 'UNKNOWN' if actual is None else ('PASS' if same(actual, expected) else 'FAIL')
    message = {'PASS': 'Declared setting meets the proposed requirement.',
               'FAIL': 'Declared setting does not meet the proposed requirement.',
               'UNKNOWN': 'Required setting is missing or null; this is not a pass.'}[status]
    return Finding(control, status, subject, path, message, control, expected, actual)


def design_status(findings: list[Finding]) -> str:
    if any(f.status == 'FAIL' for f in findings):
        return 'FAIL'
    if any(f.status == 'UNKNOWN' for f in findings):
        return 'UNKNOWN'
    return 'PASS' if findings else 'UNKNOWN'


def load_repository(root: Path = ROOT) -> tuple[dict, dict[str, dict]]:
    root = Path(root)
    catalog = load_yaml(root / 'controls.yaml')
    catalog_shape(catalog)
    patterns = {}
    for path in sorted((root / 'patterns').glob('*.yaml')):
        doc = load_yaml(path)
        pattern_shape(doc, path.name)
        if doc['id'] in patterns:
            raise InputError('Duplicate pattern ID in repository.')
        if doc['id'] in PATTERN_RULES and path.name != PATTERN_RULES[doc['id']]['filename']:
            raise InputError(f'{path.name}: filename does not match its registered pattern ID.')
        patterns[doc['id']] = doc
    return catalog, patterns


def dependency_cycle(patterns: dict[str, dict]) -> bool:
    visiting, visited = set(), set()
    def visit(pid: str) -> bool:
        if pid in visiting:
            return True
        if pid in visited or pid not in patterns:
            return False
        visiting.add(pid)
        if any(visit(ref['id']) for ref in patterns[pid]['depends_on']):
            return True
        visiting.remove(pid)
        visited.add(pid)
        return False
    return any(visit(pid) for pid in patterns)


def validate_repository(catalog: dict, patterns: dict[str, dict]) -> list[Finding]:
    """Check every required catalog item and pattern against the reviewed Python floor."""
    catalog_shape(catalog)
    for pid, doc in patterns.items():
        pattern_shape(doc, pid)
    results = []
    known = {control['id']: control for control in catalog['controls']}
    required_ids = set(RULES) | set(MANUAL_CONTROLS)
    for cid in sorted(required_ids - known.keys()):
        results.append(Finding('CATALOG-MISSING', 'FAIL', 'catalog', 'controls',
                               'Mandatory control was removed.', cid))
    for cid, control in known.items():
        if cid not in required_ids:
            results.append(Finding('CATALOG-UNSUPPORTED', 'FAIL', 'catalog', cid,
                                   'New controls require a registered rule or manual-review contract.', cid))
        elif control['verification'] != ('declared_settings' if cid in RULES else 'manual_evidence'):
            results.append(Finding('VERIFICATION-MODE', 'FAIL', 'catalog', cid,
                                   'Cannot replace an automated requirement with a manual assertion.', cid))
    for pid in sorted(PATTERN_RULES.keys() - patterns.keys()):
        results.append(Finding('PATTERN-MISSING', 'FAIL', pid, 'patterns', 'Required pattern file is missing.'))
    for pid, doc in sorted(patterns.items()):
        contract = PATTERN_RULES.get(pid)
        if not contract:
            results.append(Finding('PATTERN-UNSUPPORTED', 'FAIL', pid, 'id', 'Register the new pattern before use.'))
            continue
        if doc['track'] != contract['track']:
            results.append(Finding('PATTERN-TRACK', 'FAIL', pid, 'track', 'Pattern track was changed.'))
        deps = {ref['id'] for ref in doc['depends_on']}
        if deps != set(contract['dependencies']):
            results.append(Finding('DEPENDENCIES', 'FAIL', pid, 'depends_on', 'Required dependency set was changed.'))
        for ref in doc['depends_on']:
            if ref['id'] not in patterns or ref['version'] != patterns[ref['id']]['version']:
                results.append(Finding('REFERENCE', 'FAIL', pid, 'depends_on', 'Unknown dependency or version mismatch.'))
        listed = {row['control_id']: row for row in doc['controls']}
        for cid in sorted(set(contract['controls']) - listed.keys()):
            results.append(Finding('CONTROL-MISSING', 'FAIL', pid, 'controls', 'Mandatory pattern control was removed.', cid))
        for cid, row in listed.items():
            path = f'controls[{cid}].required_settings'
            if cid not in known or cid not in contract['controls']:
                results.append(Finding('CONTROL-REFERENCE', 'FAIL', pid, path, 'Unknown or unregistered pattern control.', cid))
                continue
            actual = row['required_settings']
            expected = RULES.get(cid, {})
            for extra in sorted(actual.keys() - expected.keys()):
                results.append(Finding('SETTING-UNKNOWN', 'FAIL', pid, path + '.' + extra,
                                       'Unknown setting; input value is not echoed.', cid))
            for key, target in expected.items():
                results.append(setting_result(pid, cid, path + '.' + key, target, actual.get(key)))
            if cid in MANUAL_CONTROLS:
                results.append(Finding(cid, 'PENDING', pid, path, 'Human evidence review remains required.', cid))
    if dependency_cycle(patterns):
        results.append(Finding('DEPENDENCY-CYCLE', 'FAIL', 'catalog', 'depends_on', 'Pattern dependencies contain a cycle.'))
    return results


def compose(patterns: dict[str, dict], selected: list[str]) -> tuple[dict, dict[str, list[str]]]:
    """Additive union only; never override a conflicting requirement."""
    expected, owners = {}, {}
    for pid in selected:
        if pid not in patterns:
            raise InputError(f'Unknown selected pattern: {pid}.')
        for control in patterns[pid]['controls']:
            for key, value in control['required_settings'].items():
                if key in expected and not same(expected[key], value):
                    raise InputError(f'Conflicting selected patterns for setting {key}; no override is allowed.')
                expected[key] = deepcopy(value)
                owners.setdefault(key, [])
                if control['control_id'] not in owners[key]:
                    owners[key].append(control['control_id'])
    return expected, owners


def workload_shape(doc: dict) -> None:
    shape(doc, {'schema_version', 'id', 'name', 'owner', 'track', 'model_mode',
                'capabilities', 'patterns', 'settings'}, {'evidence'}, 'workload')
    for key in ('id', 'name', 'owner'):
        text(doc[key], 'workload.' + key)
    if doc['schema_version'] != SUPPORTED_VERSION:
        raise InputError('workload: unsupported schema version.')
    if doc['track'] not in ('homegrown', 'saas') or doc['model_mode'] not in ('managed', 'self_hosted', 'vendor'):
        raise InputError('workload: unsupported track/model mode.')
    shape(doc['capabilities'], {'rag', 'agentic', 'mcp', 'training'}, set(), 'capabilities')
    for key, value in doc['capabilities'].items():
        if value is not None and type(value) is not bool:
            raise InputError(f'capabilities.{key}: expected true, false or null (unknown).')
    references(doc['patterns'], 'workload.patterns')
    if type(doc['settings']) is not dict or type(doc.get('evidence', {})) is not dict:
        raise InputError('workload: settings and evidence must be mappings.')
    for cid, record in doc.get('evidence', {}).items():
        shape(record, {'status', 'reference'}, set(), 'evidence.' + cid)
        if record['status'] not in ('pending', 'claimed'):
            raise InputError('Evidence can only be pending or claimed; this tool cannot verify approvals.')
        if record['reference'] is not None:
            text(record['reference'], 'evidence.' + cid + '.reference')
        if record['status'] == 'claimed' and not record['reference']:
            raise InputError('Claimed evidence requires a reference; it is still unverified.')


def required_patterns(doc: dict) -> set[str]:
    if doc['track'] == 'saas':
        return {'ABC-BASELINE', 'ABC-SAAS-AI'}
    result = {'ABC-BASELINE', 'ABC-AKS'}
    if doc['model_mode'] in ('managed', 'self_hosted'):
        result.add('ABC-INFERENCE' if doc['model_mode'] == 'managed' else 'ABC-MODEL-HOSTING')
    result.update(pid for cap, pid in CAPABILITY_PATTERNS.items() if doc['capabilities'][cap] is True)
    return result


def validate_workload(doc: dict, catalog: dict, patterns: dict[str, dict]) -> list[Finding]:
    workload_shape(doc)
    baseline = validate_repository(catalog, patterns)
    if design_status(baseline) != 'PASS':
        return [Finding('POLICY-INVALID', 'FAIL', doc['id'], 'repository',
                        'Fix the control/pattern catalog before evaluating workload conformance.')]
    subject, results = doc['id'], []
    expected_patterns = required_patterns(doc)
    selected = {ref['id'] for ref in doc['patterns']}
    if (doc['track'] == 'saas') != (doc['model_mode'] == 'vendor'):
        results.append(Finding('PROFILE-MODE', 'FAIL', subject, 'model_mode', 'Track and model mode are incompatible.'))
    for cap, value in doc['capabilities'].items():
        if value is None:
            results.append(Finding('CAPABILITY-UNKNOWN', 'UNKNOWN', subject, 'capabilities.' + cap,
                                   'Declare the capability explicitly before review.'))
        elif value and (cap == 'training' or doc['track'] == 'saas'):
            results.append(Finding('CAPABILITY-UNSUPPORTED', 'FAIL', subject, 'capabilities.' + cap,
                                   'This capability requires an additional reviewed pattern not included in this profile.'))
    for pid in sorted(expected_patterns - selected):
        results.append(Finding('PATTERN-MISSING', 'FAIL', subject, 'patterns', 'Required pattern is not selected: ' + pid))
    for pid in sorted(selected - expected_patterns):
        results.append(Finding('PATTERN-UNEXPECTED', 'FAIL', subject, 'patterns', 'Pattern is not applicable to this profile: ' + pid))
    for ref in doc['patterns']:
        if ref['id'] not in patterns or ref['version'] != patterns[ref['id']]['version']:
            results.append(Finding('PATTERN-REFERENCE', 'FAIL', subject, 'patterns', 'Unknown pattern or version mismatch.'))
    # The required set comes from the trusted profile, not from candidate pattern selection.
    settings, owners = compose(patterns, sorted(expected_patterns))
    for field in sorted(doc['settings'].keys() - settings.keys()):
        results.append(Finding('SETTING-UNKNOWN', 'FAIL', subject, 'settings.' + field,
                               'Unknown/inapplicable setting; possible credential values are not echoed.'))
    for field, required in sorted(settings.items()):
        for control_id in owners[field]:
            result = setting_result(subject, control_id, 'settings.' + field, required, doc['settings'].get(field))
            evidence = doc.get('evidence', {}).get(control_id, {}).get('status', 'pending')
            results.append(Finding(**(asdict(result) | {'evidence': evidence})))
    applicable_controls = {row['control_id'] for pid in expected_patterns for row in patterns[pid]['controls']}
    for cid in sorted(doc.get('evidence', {}).keys() - applicable_controls):
        results.append(Finding('EVIDENCE-REFERENCE', 'FAIL', subject, 'evidence.' + cid, 'Evidence refers to an inapplicable/unknown control.'))
    for cid in sorted(applicable_controls & MANUAL_CONTROLS):
        evidence = doc.get('evidence', {}).get(cid, {}).get('status', 'pending')
        results.append(Finding(cid, 'PENDING', subject, 'evidence.' + cid,
                               'Human review required; supplied references are not authenticated or inspected.', cid, evidence=evidence))
    return results


def summary(findings: list[Finding]) -> dict:
    return {'design_status': design_status(findings), 'implementation_assurance': 'UNVERIFIED',
            'authorizes_release': False,
            'counts': {status: sum(f.status == status for f in findings)
                       for status in ('PASS', 'FAIL', 'UNKNOWN', 'PENDING')},
            'findings': [asdict(f) for f in findings]}


def markdown(findings: list[Finding], title: str) -> str:
    def cell(value: Any) -> str:
        s = value if type(value) is str else json.dumps(value, ensure_ascii=True)
        return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('|', '\\|').replace('\n', ' ')
    info = summary(findings)
    rows = [f'# {cell(title)}', '', f'**Design conformance: {info["design_status"]}**', '',
            '**Implementation assurance: UNVERIFIED. Authorizes release: false.**', '',
            'Checks assess declarations, not deployed settings or runtime behavior. PENDING rows require human evidence review.', '',
            '| Pattern/workload | Control/rule | Field | Required | Declared | Result | Evidence |',
            '|---|---|---|---|---|---|---|']
    for f in findings:
        values = [f.subject, f.control_id or f.rule_id, f.field, f.required, f.declared, f.status, f.evidence]
        rows.append('| ' + ' | '.join(cell(value) for value in values) + ' |')
    problems = [f for f in findings if f.status in ('FAIL', 'UNKNOWN')]
    if problems:
        rows += ['', '## Findings and remediation', '']
        for f in problems:
            rows += [f'### {cell(f.rule_id)} — {cell(f.field)}', '', cell(f.message), '', cell(f.remediation), '']
    return '\n'.join(rows) + '\n'


def write_report(path: Path, content: str) -> None:
    """Prevent accidental overwriting of source/code files from CLI reports."""
    if path.suffix not in ('.md', '.json'):
        raise InputError('Report extension must be .md or .json.')
    if path.exists() and 'reports' not in path.resolve().parts:
        raise InputError('Refusing to overwrite an existing file outside a reports directory.')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('workload', nargs='?', type=Path, help='Optional declared workload (.yaml or .json).')
    parser.add_argument('--root', type=Path, default=ROOT, help='Control/pattern repository directory.')
    parser.add_argument('--all', '--catalog', action='store_true', dest='catalog', help='Validate all eight patterns and catalog.')
    parser.add_argument('--report', type=Path, help='Write Markdown report; nonpassing findings still appear.')
    parser.add_argument('--json-report', type=Path, help='Write machine-readable JSON report.')
    parser.add_argument('--verbose', action='store_true', help='Display passing fields as well as problems.')
    args = parser.parse_args(argv)
    if args.catalog and args.workload:
        parser.error('Use either --all/--catalog or a workload path, not both.')
    try:
        catalog, patterns = load_repository(args.root)
        findings = (validate_workload(load_yaml(args.workload), catalog, patterns) if args.workload
                    else validate_repository(catalog, patterns))
        title = 'ABC workload review' if args.workload else 'ABC controls and patterns review'
        info = summary(findings)
        print(f'Design: {info["design_status"]} | Implementation: UNVERIFIED | Authorizes release: false')
        print(' | '.join(f'{key}: {value}' for key, value in info['counts'].items()))
        for f in findings:
            if args.verbose or f.status in ('FAIL', 'UNKNOWN'):
                print(f'{f.status:7} {f.rule_id:24} {f.subject} {f.field}: {f.message}')
        if args.report:
            write_report(args.report, markdown(findings, title))
        if args.json_report:
            write_report(args.json_report, json.dumps(info, indent=2, sort_keys=True) + '\n')
        return 0 if info['design_status'] == 'PASS' else 1
    except (InputError, OSError) as exc:
        print(f'INPUT ERROR: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
